"""
Database access and management module for Student Management System.
Handles SQLite connections, schema initialization, sample data seeding,
and CRUD operations with transaction control.
"""
import sqlite3
import os
from datetime import datetime
from config import Config

# Sample student records for initial seeding
SAMPLE_STUDENTS = [
    {
        "student_id": "STU-2024-001",
        "name": "Aarav Sharma",
        "email": "aarav.sharma@example.edu",
        "department": "Computer Science",
        "year": "3rd Year",
        "phone": "+91-98765-43210",
        "status": "Active"
    },
    {
        "student_id": "STU-2024-002",
        "name": "Priya Patel",
        "email": "priya.patel@example.edu",
        "department": "Information Technology",
        "year": "2nd Year",
        "phone": "+91-98765-43211",
        "status": "Active"
    },
    {
        "student_id": "STU-2024-003",
        "name": "Rohan Gupta",
        "email": "rohan.gupta@example.edu",
        "department": "Electrical Engineering",
        "year": "4th Year",
        "phone": "+91-98765-43212",
        "status": "Active"
    },
    {
        "student_id": "STU-2024-004",
        "name": "Sneha Reddy",
        "email": "sneha.reddy@example.edu",
        "department": "Mechanical Engineering",
        "year": "1st Year",
        "phone": "+91-98765-43213",
        "status": "Active"
    },
    {
        "student_id": "STU-2024-005",
        "name": "Vikram Singh",
        "email": "vikram.singh@example.edu",
        "department": "Computer Science",
        "year": "2nd Year",
        "phone": "+91-98765-43214",
        "status": "Active"
    },
    {
        "student_id": "STU-2024-006",
        "name": "Ananya Joshi",
        "email": "ananya.joshi@example.edu",
        "department": "Civil Engineering",
        "year": "3rd Year",
        "phone": "+91-98765-43215",
        "status": "Active"
    },
    {
        "student_id": "STU-2024-007",
        "name": "Devansh Nair",
        "email": "devansh.nair@example.edu",
        "department": "Information Technology",
        "year": "4th Year",
        "phone": "+91-98765-43216",
        "status": "Active"
    },
    {
        "student_id": "STU-2024-008",
        "name": "Meera Iyer",
        "email": "meera.iyer@example.edu",
        "department": "Electrical Engineering",
        "year": "1st Year",
        "phone": "+91-98765-43217",
        "status": "Active"
    }
]

SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS students (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    student_id TEXT UNIQUE NOT NULL,
    name TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL,
    department TEXT NOT NULL,
    year TEXT NOT NULL,
    phone TEXT NOT NULL,
    status TEXT DEFAULT 'Active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_student_id ON students(student_id);
CREATE INDEX IF NOT EXISTS idx_student_department ON students(department);
"""

def get_db_connection(db_path=None):
    """
    Establish a connection to the specified SQLite database file.
    Row factory is set to sqlite3.Row for dictionary-like access.
    """
    target_path = db_path or Config.PRIMARY_DB_PATH
    conn = sqlite3.connect(target_path, timeout=10.0)
    conn.row_factory = sqlite3.Row
    return conn

def init_db(db_path=None, reset=False):
    """
    Initialize database schema.
    """
    target_path = db_path or Config.PRIMARY_DB_PATH
    if reset and os.path.exists(target_path):
        try:
            os.remove(target_path)
        except OSError:
            pass

    conn = get_db_connection(target_path)
    try:
        cursor = conn.cursor()
        cursor.executescript(SCHEMA_SQL)
        conn.commit()
    finally:
        conn.close()

def seed_sample_data(db_path=None, students_list=None):
    """
    Seed initial student records into the database.
    """
    target_path = db_path or Config.PRIMARY_DB_PATH
    students = students_list if students_list is not None else SAMPLE_STUDENTS
    
    conn = get_db_connection(target_path)
    try:
        cursor = conn.cursor()
        for s in students:
            cursor.execute("""
                INSERT OR IGNORE INTO students 
                (student_id, name, email, department, year, phone, status, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
            """, (s["student_id"], s["name"], s["email"], s["department"], s["year"], s["phone"], s.get("status", "Active")))
        conn.commit()
    finally:
        conn.close()

def setup_all_databases():
    """
    Sets up:
    1. Primary DB (students.db) - with all 8 sample records.
    2. Stale DB (students_stale.db) - frozen with only the first 3 records to simulate stale connection.
    3. Replica DB (students_replica.db) - frozen snapshot with 5 records to simulate split DB read/write.
    """
    # 1. Primary DB
    init_db(Config.PRIMARY_DB_PATH, reset=True)
    seed_sample_data(Config.PRIMARY_DB_PATH, SAMPLE_STUDENTS)

    # 2. Stale DB
    init_db(Config.STALE_DB_PATH, reset=True)
    seed_sample_data(Config.STALE_DB_PATH, SAMPLE_STUDENTS[:3])

    # 3. Replica DB
    init_db(Config.REPLICA_DB_PATH, reset=True)
    seed_sample_data(Config.REPLICA_DB_PATH, SAMPLE_STUDENTS[:5])

def get_all_students(db_path=None, custom_query=None, params=None):
    """
    Fetch all student records from database, sorted by latest first.
    Allows custom queries for debugging scenarios (e.g. faulty SELECT).
    """
    conn = get_db_connection(db_path)
    try:
        cursor = conn.cursor()
        query = custom_query or "SELECT * FROM students ORDER BY id DESC"
        parameters = params or ()
        cursor.execute(query, parameters)
        rows = cursor.fetchall()
        return [dict(row) for row in rows]
    finally:
        conn.close()

def get_student_by_id(student_id, db_path=None):
    """
    Fetch a single student by their unique student_id.
    """
    conn = get_db_connection(db_path)
    try:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM students WHERE student_id = ?", (student_id,))
        row = cursor.fetchone()
        return dict(row) if row else None
    finally:
        conn.close()

def insert_student(student_data, db_path=None, auto_commit=True):
    """
    Insert a new student record into the database.
    If auto_commit is False, the transaction is intentionally NOT committed.
    This allows simulating the transaction uncommitted bug!
    """
    conn = get_db_connection(db_path)
    try:
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO students (student_id, name, email, department, year, phone, status, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
        """, (
            student_data["student_id"],
            student_data["name"],
            student_data["email"],
            student_data["department"],
            student_data["year"],
            student_data["phone"],
            student_data.get("status", "Active")
        ))
        
        last_id = cursor.lastrowid
        
        if auto_commit:
            conn.commit()
            committed = True
        else:
            # Transaction is left uncommitted (closing connection rolls back in SQLite)
            committed = False
            
        return {"id": last_id, "student_id": student_data["student_id"], "committed": committed}
    finally:
        conn.close()

def update_student(student_id, student_data, db_path=None):
    """
    Update an existing student record.
    """
    conn = get_db_connection(db_path)
    try:
        cursor = conn.cursor()
        cursor.execute("""
            UPDATE students 
            SET name = ?, email = ?, department = ?, year = ?, phone = ?, status = ?, updated_at = CURRENT_TIMESTAMP
            WHERE student_id = ?
        """, (
            student_data["name"],
            student_data["email"],
            student_data["department"],
            student_data["year"],
            student_data["phone"],
            student_data.get("status", "Active"),
            student_id
        ))
        conn.commit()
        return cursor.rowcount > 0
    finally:
        conn.close()

def delete_student(student_id, db_path=None):
    """
    Delete a student record by student_id.
    """
    conn = get_db_connection(db_path)
    try:
        cursor = conn.cursor()
        cursor.execute("DELETE FROM students WHERE student_id = ?", (student_id,))
        conn.commit()
        return cursor.rowcount > 0
    finally:
        conn.close()

def get_statistics(db_path=None, custom_query=None):
    """
    Compute dashboard statistics:
    - Total students
    - Department distribution
    - Year-wise breakdown
    - Active vs Inactive count
    """
    conn = get_db_connection(db_path)
    try:
        cursor = conn.cursor()
        
        # Total count
        if custom_query:
            cursor.execute(custom_query)
        else:
            cursor.execute("SELECT COUNT(*) AS total FROM students")
        total = cursor.fetchone()["total"]

        # Department distribution
        cursor.execute("SELECT department, COUNT(*) AS count FROM students GROUP BY department ORDER BY count DESC")
        departments = [dict(row) for row in cursor.fetchall()]

        # Year distribution
        cursor.execute("SELECT year, COUNT(*) AS count FROM students GROUP BY year ORDER BY year ASC")
        years = [dict(row) for row in cursor.fetchall()]

        # Status distribution
        cursor.execute("SELECT status, COUNT(*) AS count FROM students GROUP BY status")
        statuses = [dict(row) for row in cursor.fetchall()]

        return {
            "total_students": total,
            "department_distribution": departments,
            "year_distribution": years,
            "status_distribution": statuses
        }
    finally:
        conn.close()

def get_raw_database_summary():
    """
    Inspection utility to report actual rows across all database files
    for real-time diagnostic comparisons.
    """
    results = {}
    db_configs = [
        ("primary", Config.PRIMARY_DB_PATH),
        ("stale", Config.STALE_DB_PATH),
        ("replica", Config.REPLICA_DB_PATH)
    ]
    
    for name, path in db_configs:
        if os.path.exists(path):
            try:
                conn = sqlite3.connect(path)
                cursor = conn.cursor()
                cursor.execute("SELECT COUNT(*) FROM students")
                count = cursor.fetchone()[0]
                cursor.execute("SELECT student_id, name, created_at FROM students ORDER BY id DESC LIMIT 5")
                latest = [{"student_id": r[0], "name": r[1], "created_at": r[2]} for r in cursor.fetchall()]
                conn.close()
                results[name] = {
                    "path": path,
                    "exists": True,
                    "count": count,
                    "latest": latest,
                    "file_size_bytes": os.path.getsize(path)
                }
            except Exception as e:
                results[name] = {"path": path, "exists": True, "error": str(e)}
        else:
            results[name] = {"path": path, "exists": False, "count": 0}
            
    return results
