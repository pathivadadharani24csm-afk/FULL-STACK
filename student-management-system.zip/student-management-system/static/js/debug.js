/**
 * Student Management System - Debugging Lab & 10-Step Diagnostic Engine
 * Manages bug simulation, multi-layer verification matrix,
 * raw SQLite disk inspection, code diff viewer, and 10-step interactive procedure.
 */

// Debug State
let currentScenario = null;
let tenStepProcedure = [];
let completedSteps = new Set();

document.addEventListener('DOMContentLoaded', () => {
    initDebugLab();
    initTenStepDebugger();
    initApiExplorer();
});

// ================= Debug Lab Initialization =================
function initDebugLab() {
    const scenarioSelect = document.getElementById('select-debug-scenario');
    const btnRestore = document.getElementById('btn-restore-healthy');
    const btnReproduce = document.getElementById('btn-reproduce-bug');
    const btnInspectDb = document.getElementById('btn-inspect-db-now');

    if (scenarioSelect) {
        scenarioSelect.addEventListener('change', (e) => {
            setScenario(e.target.value);
        });
    }

    if (btnRestore) {
        btnRestore.addEventListener('click', restoreHealthyMode);
    }

    if (btnReproduce) {
        btnReproduce.addEventListener('click', reproduceBugAutomatically);
    }

    if (btnInspectDb) {
        btnInspectDb.addEventListener('click', openRawDatabaseInspector);
    }
}

// ================= Sync & Set Debug Scenarios =================
async function syncDebugStatus() {
    try {
        const res = await fetch('/api/debug/status');
        const data = await res.json();
        if (data.status !== 'success') return;

        currentScenario = data.current_scenario;
        tenStepProcedure = data.ten_step_procedure;
        AppState.debugMode = currentScenario.id;

        updateDebugBadges(currentScenario);
        updateScenarioCard(currentScenario);
        renderTenStepAccordion(tenStepProcedure);
        updateMatrixCounters();

        const scenarioSelect = document.getElementById('select-debug-scenario');
        if (scenarioSelect) {
            scenarioSelect.value = currentScenario.id;
        }

    } catch (err) {
        console.error("Failed to sync debug status:", err);
    }
}

async function setScenario(scenarioId) {
    try {
        const res = await fetch('/api/debug/set-scenario', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ scenario_id: scenarioId })
        });
        const data = await res.json();
        if (data.status === 'success') {
            currentScenario = data.scenario;
            AppState.debugMode = currentScenario.id;
            updateDebugBadges(currentScenario);
            updateScenarioCard(currentScenario);
            showToast(`Activated: ${currentScenario.name}`, currentScenario.id === 'FIXED' ? 'success' : 'warning');
            updateMatrixCounters();
            loadStudents();
            loadDashboardStats();
        }
    } catch (err) {
        showToast(err.message, 'error');
    }
}

async function restoreHealthyMode() {
    try {
        const res = await fetch('/api/debug/reset-scenario', { method: 'POST' });
        const data = await res.json();
        if (data.status === 'success') {
            currentScenario = data.current_scenario;
            AppState.debugMode = 'FIXED';
            const sel = document.getElementById('select-debug-scenario');
            if (sel) sel.value = 'FIXED';
            updateDebugBadges(currentScenario);
            updateScenarioCard(currentScenario);
            showToast('System restored to Healthy / Fixed mode!', 'success');
            await loadStudents();
            await loadDashboardStats();
            updateMatrixCounters();
        }
    } catch (err) {
        showToast(err.message, 'error');
    }
}

function updateDebugBadges(scenario) {
    const topBadge = document.getElementById('top-debug-badge');
    const topText = document.getElementById('top-debug-text');
    const sidebarPill = document.getElementById('sidebar-status-pill');
    const sidebarText = document.getElementById('sidebar-status-text');

    const isBuggy = scenario.id !== 'FIXED';

    if (topBadge) {
        topBadge.classList.toggle('buggy', isBuggy);
        topBadge.innerHTML = isBuggy 
            ? `<i class="bi bi-bug-fill text-danger"></i> <span id="top-debug-text">Bug Active: ${scenario.name.split(':')[0]}</span>`
            : `<i class="bi bi-shield-check text-success"></i> <span id="top-debug-text">Mode: FIXED (Healthy)</span>`;
    }

    if (sidebarPill) {
        sidebarPill.classList.toggle('warning', isBuggy);
        sidebarText.textContent = isBuggy ? `Simulating: ${scenario.name.split(':')[0]}` : 'System: Healthy (Fixed)';
    }

    const statStatus = document.getElementById('stat-system-status');
    if (statStatus) {
        statStatus.textContent = isBuggy ? 'Bug Active' : 'Operational';
        statStatus.className = isBuggy ? 'stat-card-value text-danger' : 'stat-card-value text-success';
    }
}

function updateScenarioCard(scenario) {
    if (!scenario) return;

    document.getElementById('scenario-name').textContent = scenario.name;
    const catBadge = document.getElementById('scenario-category');
    catBadge.textContent = scenario.category;
    catBadge.className = scenario.category.includes('Database') ? 'badge bg-danger px-3 py-2' : 'badge bg-warning text-dark px-3 py-2';

    document.getElementById('scenario-symptom').textContent = scenario.symptom;
    document.getElementById('scenario-root-cause').textContent = scenario.root_cause;
    document.getElementById('scenario-focus').textContent = scenario.diagnostic_focus;

    document.getElementById('code-diff-buggy').textContent = scenario.buggy_code;
    document.getElementById('code-diff-fixed').textContent = scenario.fixed_code;
}

// ================= 1-Click Reproduce Bug =================
async function reproduceBugAutomatically() {
    if (AppState.debugMode === 'FIXED') {
        showToast('Select a bug scenario first from the dropdown to demonstrate!', 'warning');
        return;
    }

    showToast(`Reproducing ${currentScenario.name}...`, 'info');
    const randomNum = Math.floor(700 + Math.random() * 299);
    const testId = `STU-2024-${randomNum}`;

    const testPayload = {
        student_id: testId,
        name: `Test Student (${currentScenario.id.slice(0, 8)})`,
        email: `test.${randomNum}@example.edu`,
        department: "Computer Science",
        year: "3rd Year",
        phone: `+91-98765-43${randomNum}`
    };

    try {
        const response = await fetch('/api/students', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(testPayload)
        });

        const postData = await response.json();
        
        // Attempt reloading students
        await loadStudents();
        await updateMatrixCounters();

        // Check if new student appears in UI table
        const foundInUI = AppState.students && AppState.students.some(s => s.student_id === testId);

        if (!foundInUI) {
            showToast(`[Bug Demonstrated!] Record submitted but NOT displayed in Student Directory!`, 'error');
            switchView('debug-lab');
        } else {
            showToast(`Record displayed successfully.`, 'success');
        }

    } catch (err) {
        showToast(`Simulation Error: ${err.message}`, 'error');
        await updateMatrixCounters();
    }
}

// ================= Multi-Layer Verification Matrix =================
async function updateMatrixCounters() {
    try {
        // 1. Fetch raw disk inspection
        const inspectRes = await fetch('/api/debug/inspect-db');
        const inspectData = await inspectRes.json();
        
        const primaryCount = inspectData.disk_databases?.primary?.count || 0;
        document.getElementById('matrix-db-count').textContent = primaryCount;

        // 2. Fetch API payload count
        let apiCount = 0;
        try {
            const apiRes = await fetch('/api/students');
            const apiJson = await apiRes.json();
            apiCount = (apiJson.students || []).length;
        } catch {
            apiCount = 0;
        }
        document.getElementById('matrix-api-count').textContent = apiCount;

        // 3. UI DOM row count
        const uiCount = (AppState.students || []).length;
        document.getElementById('matrix-ui-count').textContent = uiCount;

        // 4. Triangulate Discrepancy
        const pipelineStatus = document.getElementById('matrix-pipeline-status');
        const pipelineBadge = document.getElementById('matrix-pipeline-badge');
        const banner = document.getElementById('dashboard-discrepancy-banner');

        const isDiscrepant = (primaryCount !== apiCount) || (apiCount !== uiCount) || (AppState.debugMode !== 'FIXED');

        if (!isDiscrepant && AppState.debugMode === 'FIXED') {
            pipelineStatus.textContent = "SYNCHRONIZED";
            pipelineStatus.className = "h3 fw-bold text-success my-1";
            pipelineBadge.textContent = "HEALTHY (ALL LAYERS IN SYNC)";
            pipelineBadge.className = "badge bg-success";
            if (banner) banner.classList.add('d-none');
        } else {
            pipelineStatus.textContent = "DISCREPANCY!";
            pipelineStatus.className = "h3 fw-bold text-danger my-1";
            
            let discrepancyNote = "MISMATCH DETECTED";
            if (primaryCount !== apiCount) {
                discrepancyNote = "DATABASE / QUERY LAYER BREAKDOWN";
            } else if (apiCount !== uiCount) {
                discrepancyNote = "APPLICATION / FRONTEND LAYER BREAKDOWN";
            }
            pipelineBadge.textContent = discrepancyNote;
            pipelineBadge.className = "badge bg-danger";

            if (banner) {
                banner.classList.remove('d-none');
                document.getElementById('disc-db-count').textContent = primaryCount;
                document.getElementById('disc-api-count').textContent = apiCount;
                document.getElementById('discrepancy-banner-msg').textContent = 
                    `Active Issue: ${currentScenario ? currentScenario.name : 'Pipeline Mismatch'}. SQLite has ${primaryCount} records, API returned ${apiCount}, UI table rendered ${uiCount}.`;
            }
        }

    } catch (err) {
        console.warn("Could not update matrix counters:", err);
    }
}

// ================= Raw SQLite Database Inspector =================
async function openRawDatabaseInspector() {
    try {
        const res = await fetch('/api/debug/inspect-db');
        const data = await res.json();
        if (data.status !== 'success') return;

        // Update counts
        document.getElementById('badge-db-primary-count').textContent = data.primary_db_records.length;
        document.getElementById('badge-db-stale-count').textContent = data.stale_db_records.length;
        document.getElementById('badge-db-replica-count').textContent = data.replica_db_records.length;

        // Render tables
        renderRawTable('raw-db-primary-tbody', data.primary_db_records);
        renderRawTable('raw-db-stale-tbody', data.stale_db_records);
        renderRawTable('raw-db-replica-tbody', data.replica_db_records);

        const modal = new bootstrap.Modal(document.getElementById('modal-inspect-db'));
        modal.show();
    } catch (e) {
        showToast(e.message, 'error');
    }
}

function renderRawTable(tbodyId, records) {
    const tbody = document.getElementById(tbodyId);
    if (!tbody) return;
    if (!records || records.length === 0) {
        tbody.innerHTML = `<tr><td colspan="8" class="text-center text-muted py-3">No records found in this database file.</td></tr>`;
        return;
    }
    tbody.innerHTML = records.map(r => `
        <tr>
            <td>${r.id}</td>
            <td><code>${r.student_id}</code></td>
            <td><strong>${escapeHtml(r.name)}</strong></td>
            <td>${escapeHtml(r.email)}</td>
            <td>${escapeHtml(r.department)}</td>
            <td>${escapeHtml(r.year)}</td>
            <td><span class="badge ${r.status === 'Active' ? 'bg-success' : 'bg-secondary'}">${r.status || 'Active'}</span></td>
            <td><small class="text-muted">${r.created_at || ''}</small></td>
        </tr>
    `).join('');
}

// ================= 10-Step Systematic Debugger =================
function initTenStepDebugger() {
    const btnReset = document.getElementById('btn-reset-steps');
    if (btnReset) {
        btnReset.addEventListener('click', () => {
            completedSteps.clear();
            renderTenStepAccordion(tenStepProcedure);
            updateDebuggerProgress();
            showToast('Debugger checklist reset.', 'info');
        });
    }
}

function renderTenStepAccordion(steps) {
    const container = document.getElementById('ten-steps-accordion');
    if (!container || !steps || steps.length === 0) return;

    container.innerHTML = steps.map((s, idx) => {
        const isDone = completedSteps.has(s.step);
        return `
            <div class="step-card ${isDone ? 'completed' : ''}" id="step-card-${s.step}">
                <div class="step-header" onclick="toggleStepContent(${s.step})">
                    <div class="d-flex align-items-center">
                        <div class="step-badge ${isDone ? 'completed' : ''}">
                            ${isDone ? '<i class="bi bi-check-lg"></i>' : s.step}
                        </div>
                        <div>
                            <h6 class="mb-0 fw-bold">${s.title}</h6>
                            <small class="text-muted">${s.description}</small>
                        </div>
                    </div>
                    <div class="d-flex align-items-center gap-3">
                        <span class="badge bg-light text-secondary border small">${s.tool}</span>
                        <div class="form-check m-0" onclick="event.stopPropagation()">
                            <input class="form-check-input" type="checkbox" id="check-step-${s.step}" 
                                   ${isDone ? 'checked' : ''} onchange="toggleStepCompleted(${s.step}, this.checked)">
                        </div>
                        <i class="bi bi-chevron-down text-muted" id="step-chevron-${s.step}"></i>
                    </div>
                </div>

                <div class="step-content d-none" id="step-content-${s.step}">
                    <div class="p-3 bg-white rounded border">
                        <h6 class="fw-bold text-primary mb-2"><i class="bi bi-terminal me-1"></i> Diagnostic Execution:</h6>
                        <pre class="bg-dark text-light p-2 rounded font-monospace small mb-3">${escapeHtml(s.action)}</pre>
                        
                        <div class="d-flex justify-content-between align-items-center">
                            <span class="small text-muted">Perform this check to isolate the issue.</span>
                            <button class="btn btn-sm btn-primary-blue" onclick="executeStepDiagnostic(${s.step})">
                                Run Diagnostic Tool <i class="bi bi-arrow-right"></i>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }).join('');

    updateDebuggerProgress();
}

function toggleStepContent(stepNum) {
    const content = document.getElementById(`step-content-${stepNum}`);
    const chevron = document.getElementById(`step-chevron-${stepNum}`);
    if (!content) return;

    const isHidden = content.classList.contains('d-none');
    content.classList.toggle('d-none', !isHidden);
    if (chevron) {
        chevron.className = isHidden ? 'bi bi-chevron-up text-primary' : 'bi bi-chevron-down text-muted';
    }
}

function toggleStepCompleted(stepNum, isChecked) {
    if (isChecked) {
        completedSteps.add(stepNum);
    } else {
        completedSteps.delete(stepNum);
    }
    const card = document.getElementById(`step-card-${stepNum}`);
    if (card) card.classList.toggle('completed', isChecked);
    updateDebuggerProgress();
}

function updateDebuggerProgress() {
    const badge = document.getElementById('debugger-progress-badge');
    if (!badge) return;
    badge.textContent = `Progress: ${completedSteps.size} / 10 Completed`;
    if (completedSteps.size === 10) {
        badge.className = "badge bg-success py-2 px-3 fw-bold";
        badge.textContent = "All 10 Steps Verified & Completed!";
    } else {
        badge.className = "badge bg-primary-subtle text-primary py-2 px-3 fw-bold";
    }
}

function executeStepDiagnostic(stepNum) {
    switch (stepNum) {
        case 1:
            // Reproduce
            switchView('debug-lab');
            reproduceBugAutomatically();
            break;
        case 2:
            // Check DB
            openRawDatabaseInspector();
            break;
        case 3:
            // Verify connections
            switchView('debug-lab');
            break;
        case 4:
            // SQL queries
            switchView('logs-api');
            break;
        case 5:
            // Flask logs
            switchView('logs-api');
            break;
        case 6:
            // API endpoints
            switchView('logs-api');
            break;
        case 7:
            // Console errors
            showToast('Open Browser Developer Tools (F12 -> Console) to inspect frontend errors.', 'info');
            break;
        case 8:
            // Verify responses
            switchView('logs-api');
            break;
        case 9:
            // Fix issue
            restoreHealthyMode();
            break;
        case 10:
            // Retest
            switchView('test-runner');
            runAllTestsUI();
            break;
    }
    completedSteps.add(stepNum);
    updateDebuggerProgress();
    const chk = document.getElementById(`check-step-${stepNum}`);
    if (chk) chk.checked = true;
    const card = document.getElementById(`step-card-${stepNum}`);
    if (card) card.classList.add('completed');
}

// ================= Terminal Logs & API Explorer =================
function initApiExplorer() {
    const btnSend = document.getElementById('btn-send-api-req');
    const methodSelect = document.getElementById('api-method-select');
    const bodyWrapper = document.getElementById('api-body-wrapper');
    const btnRefreshLogs = document.getElementById('btn-refresh-logs');
    const btnClearLogs = document.getElementById('btn-clear-logs');

    if (btnSend) btnSend.addEventListener('click', sendApiExplorerRequest);

    if (methodSelect && bodyWrapper) {
        methodSelect.addEventListener('change', () => {
            const m = methodSelect.value;
            bodyWrapper.classList.toggle('d-none', m === 'GET' || m === 'DELETE');
        });
    }

    if (btnRefreshLogs) btnRefreshLogs.addEventListener('click', fetchLogs);
    if (btnClearLogs) {
        btnClearLogs.addEventListener('click', async () => {
            await fetch('/api/debug/clear-logs', { method: 'POST' });
            fetchLogs();
            showToast('Backend log stream cleared.', 'info');
        });
    }

    // Preset buttons
    document.querySelectorAll('.api-preset-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            const method = btn.getAttribute('data-method');
            const url = btn.getAttribute('data-url');
            if (methodSelect) {
                methodSelect.value = method;
                bodyWrapper.classList.toggle('d-none', method === 'GET' || method === 'DELETE');
            }
            const inputUrl = document.getElementById('api-url-input');
            if (inputUrl) inputUrl.value = url;
            sendApiExplorerRequest();
        });
    });
}

async function fetchLogs() {
    const terminal = document.getElementById('terminal-log-content');
    if (!terminal) return;

    try {
        const res = await fetch('/api/debug/logs?limit=40');
        const data = await res.json();
        if (data.status !== 'success') return;

        const logs = data.logs || [];
        if (logs.length === 0) {
            terminal.innerHTML = `<div class="text-muted small">No logs recorded yet.</div>`;
            return;
        }

        terminal.innerHTML = logs.map(l => {
            const badgeClass = l.level === 'ERROR' ? 'level-error' : (l.level === 'WARN' ? 'level-warn' : 'level-info');
            return `
                <div class="log-entry">
                    <span class="log-time">[${l.timestamp.split(' ')[1]}]</span>
                    <span class="log-level-badge ${badgeClass}">${l.level}</span>
                    <span class="flex-grow-1">${escapeHtml(l.message)}</span>
                </div>
            `;
        }).join('');

        terminal.scrollTop = terminal.scrollHeight;
    } catch (e) {
        terminal.innerHTML = `<div class="text-danger small">Failed to stream logs: ${escapeHtml(e.message)}</div>`;
    }
}

async function sendApiExplorerRequest() {
    const method = document.getElementById('api-method-select').value;
    const url = document.getElementById('api-url-input').value.trim();
    const bodyText = document.getElementById('api-body-input').value;
    const resStatus = document.getElementById('api-response-status');
    const resBody = document.getElementById('api-response-body');

    resStatus.className = 'badge bg-warning text-dark';
    resStatus.textContent = 'Sending...';

    const options = { method: method };
    if (method === 'POST' || method === 'PUT') {
        options.headers = { 'Content-Type': 'application/json' };
        try {
            options.body = JSON.stringify(JSON.parse(bodyText));
        } catch {
            options.body = bodyText;
        }
    }

    try {
        const startTime = performance.now();
        const response = await fetch(url, options);
        const duration = Math.round(performance.now() - startTime);

        let data;
        const contentType = response.headers.get('content-type') || '';
        if (contentType.includes('application/json')) {
            data = await response.json();
            resBody.textContent = JSON.stringify(data, null, 2);
        } else {
            resBody.textContent = await response.text();
        }

        resStatus.className = response.ok ? 'badge bg-success' : 'badge bg-danger';
        resStatus.textContent = `${response.status} ${response.statusText} (${duration} ms)`;
        fetchLogs();
    } catch (err) {
        resStatus.className = 'badge bg-danger';
        resStatus.textContent = 'Network Error';
        resBody.textContent = err.message;
    }
}
