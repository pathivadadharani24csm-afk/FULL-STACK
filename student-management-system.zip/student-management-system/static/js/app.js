/**
 * Student Management System - Core Frontend Application Logic
 * Manages Dashboard stats, Charts, Student CRUD operations,
 * search/filtering, and responsive UI interactions.
 */

// Application State
const AppState = {
    students: [],
    stats: null,
    activeView: 'dashboard',
    charts: {
        departments: null,
        years: null
    },
    debugMode: 'FIXED'
};

// Available sample data pool for quick autofill
const SAMPLE_STUDENT_POOL = [
    { name: "Tanvi Sen", dept: "Computer Science", year: "2nd Year", phone: "+91-98765-43011" },
    { name: "Arjun Verma", dept: "Information Technology", year: "3rd Year", phone: "+91-98765-43012" },
    { name: "Meera Iyer", dept: "Electrical Engineering", year: "1st Year", phone: "+91-98765-43013" },
    { name: "Kunal Deshmukh", dept: "Mechanical Engineering", year: "4th Year", phone: "+91-98765-43014" },
    { name: "Rhea Mukherjee", dept: "Civil Engineering", year: "2nd Year", phone: "+91-98765-43015" },
    { name: "Aditya Nair", dept: "Data Science", year: "3rd Year", phone: "+91-98765-43016" }
];

document.addEventListener('DOMContentLoaded', () => {
    initNavigation();
    initEventListeners();
    loadDashboardStats();
    loadStudents();
    syncDebugStatus();
});

// ================= Navigation & View Switching =================
function initNavigation() {
    const navLinks = document.querySelectorAll('.sidebar-nav .nav-item-link');
    navLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const view = link.getAttribute('data-view');
            switchView(view);
        });
    });

    // Check URL hash if present
    const hash = window.location.hash.replace('#', '');
    if (hash && document.getElementById(`view-${hash}`)) {
        switchView(hash);
    }
}

function switchView(viewName) {
    AppState.activeView = viewName;
    
    // Update sidebar active class
    document.querySelectorAll('.sidebar-nav .nav-item-link').forEach(l => {
        l.classList.toggle('active', l.getAttribute('data-view') === viewName);
    });

    // Hide all view sections, show target
    document.querySelectorAll('.view-section').forEach(sec => {
        sec.classList.remove('active');
    });

    const targetSection = document.getElementById(`view-${viewName}`);
    if (targetSection) {
        targetSection.classList.add('active');
    }

    // Update Header titles
    const titles = {
        'dashboard': { title: 'Dashboard Overview', desc: 'Monitor student registrations, department metrics, and system health.' },
        'students': { title: 'Student Directory', desc: 'Browse, search, edit, and manage all enrolled student records.' },
        'add-student': { title: 'Register Student', desc: 'Fill the form to enroll a new student in the system.' },
        'debug-lab': { title: 'Interactive Debugging Lab', desc: 'Reproduce, simulate, and diagnose database and application discrepancies.' },
        'systematic-debugger': { title: '10-Step Systematic Debugger', desc: 'Standardized step-by-step procedure to isolate and fix issues.' },
        'test-runner': { title: 'Automated Test Suite Runner', desc: 'Execute Unit, Database, API, Integration, Frontend, and E2E test cases.' },
        'logs-api': { title: 'System Logs & API Explorer', desc: 'Inspect live Flask logs and test REST endpoints directly.' }
    };

    if (titles[viewName]) {
        document.getElementById('header-view-title').textContent = titles[viewName].title;
        document.getElementById('header-view-desc').textContent = titles[viewName].desc;
    }

    window.location.hash = viewName;

    // View-specific refreshes
    if (viewName === 'dashboard') {
        loadDashboardStats();
        loadStudents();
    } else if (viewName === 'students') {
        loadStudents();
    } else if (viewName === 'logs-api') {
        fetchLogs();
    } else if (viewName === 'debug-lab') {
        updateMatrixCounters();
    }
}

// ================= Event Listeners Initialization =================
function initEventListeners() {
    // Form submission
    const formAdd = document.getElementById('form-add-student');
    if (formAdd) {
        formAdd.addEventListener('submit', handleAddStudent);
    }

    // Edit form submission
    const formEdit = document.getElementById('form-edit-student');
    if (formEdit) {
        formEdit.addEventListener('submit', handleEditStudent);
    }

    // Delete confirmation button
    const btnConfirmDelete = document.getElementById('btn-confirm-delete');
    if (btnConfirmDelete) {
        btnConfirmDelete.addEventListener('click', handleConfirmDelete);
    }

    // Search and filters
    const filterSearch = document.getElementById('filter-search');
    const filterDept = document.getElementById('filter-department');
    const filterYear = document.getElementById('filter-year');

    if (filterSearch) filterSearch.addEventListener('input', debounce(filterStudentTable, 250));
    if (filterDept) filterDept.addEventListener('change', filterStudentTable);
    if (filterYear) filterYear.addEventListener('change', filterStudentTable);

    // Refresh button
    const btnRefresh = document.getElementById('btn-refresh-students');
    if (btnRefresh) {
        btnRefresh.addEventListener('click', () => {
            loadStudents();
            showToast('Student list refreshed', 'info');
        });
    }

    // Autofill Sample Data
    const btnAutofill = document.getElementById('btn-autofill-sample');
    if (btnAutofill) {
        btnAutofill.addEventListener('click', handleAutofillSample);
    }

    // Generate Next ID
    const btnGenId = document.getElementById('btn-generate-id');
    if (btnGenId) {
        btnGenId.addEventListener('click', generateNextStudentID);
    }

    // Export CSV
    const btnExport = document.getElementById('btn-export-csv');
    if (btnExport) {
        btnExport.addEventListener('click', exportStudentsToCSV);
    }

    // Reset DB button in header
    const btnResetDB = document.getElementById('btn-quick-reset');
    if (btnResetDB) {
        btnResetDB.addEventListener('click', async () => {
            if (confirm("Reset databases and restore clean sample data?")) {
                await fetch('/api/debug/reset-database', { method: 'POST' });
                showToast('Databases re-seeded and restored to clean state.', 'success');
                loadDashboardStats();
                loadStudents();
                syncDebugStatus();
            }
        });
    }
}

// ================= Load & Render Students =================
async function loadStudents() {
    const tbody = document.getElementById('students-tbody');
    const recentTbody = document.getElementById('recent-students-tbody');

    // Determine target API endpoint
    let endpoint = '/api/students';

    // Bug Simulation APP-3: Incorrect Endpoint
    if (AppState.debugMode === 'APP_WRONG_ENDPOINT') {
        endpoint = '/api/v1/get_all_students'; // Intentionally 404
    }

    try {
        const response = await fetch(endpoint);
        
        if (!response.ok) {
            throw new Error(`HTTP Error ${response.status}: Failed to fetch from '${endpoint}'`);
        }

        const data = await response.json();
        
        // Bug Simulation APP-4: Key Mismatch (data.students vs data.student_records)
        let studentsList = data.students;
        if (AppState.debugMode === 'APP_KEY_MISMATCH' && !studentsList) {
            // Frontend fails silently or throws because key was misnamed in backend
            console.error("APP_KEY_MISMATCH Error: Property 'students' is undefined in response!", data);
            studentsList = undefined;
        }

        if (studentsList === undefined) {
            throw new Error("TypeError: Cannot read properties of undefined (reading 'students')");
        }

        AppState.students = studentsList;
        renderStudentsTable(AppState.students);
        renderRecentStudents(AppState.students);
        updateMatrixCounters();

    } catch (err) {
        console.error("Error loading students:", err);
        const errorHtml = `
            <tr>
                <td colspan="8" class="text-center py-4 text-danger">
                    <i class="bi bi-exclamation-triangle-fill fs-4 d-block mb-2"></i>
                    <strong>Failed to load student records:</strong> ${escapeHtml(err.message)}
                    <div class="mt-2">
                        <button class="btn btn-sm btn-outline-danger" onclick="switchView('debug-lab')">
                            Diagnose in Debugging Lab
                        </button>
                    </div>
                </td>
            </tr>
        `;
        if (tbody) tbody.innerHTML = errorHtml;
        if (recentTbody) recentTbody.innerHTML = `<tr><td colspan="7" class="text-center py-3 text-danger">${escapeHtml(err.message)}</td></tr>`;
        updateMatrixCounters();
    }
}

function renderStudentsTable(students) {
    const tbody = document.getElementById('students-tbody');
    const countBadge = document.getElementById('student-count-badge');
    if (!tbody) return;

    if (countBadge) {
        countBadge.textContent = `${students.length} Student${students.length === 1 ? '' : 's'}`;
    }

    if (students.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="8" class="text-center py-5 text-muted">
                    <i class="bi bi-inbox fs-1 text-secondary d-block mb-2"></i>
                    <h5>No student records found</h5>
                    <p class="small">No records match the current filter criteria or database table is empty.</p>
                </td>
            </tr>
        `;
        return;
    }

    tbody.innerHTML = students.map(s => {
        const initials = getInitials(s.name);
        return `
            <tr>
                <td>
                    <div class="d-flex align-items-center gap-2">
                        <div class="student-avatar">${initials}</div>
                        <div>
                            <div class="fw-bold">${escapeHtml(s.name)}</div>
                            <small class="text-muted">${escapeHtml(s.email)}</small>
                        </div>
                    </div>
                </td>
                <td><code class="fw-bold text-dark">${escapeHtml(s.student_id)}</code></td>
                <td><span class="small text-secondary"><i class="bi bi-telephone me-1"></i>${escapeHtml(s.phone)}</span></td>
                <td><span class="badge-dept">${escapeHtml(s.department)}</span></td>
                <td><span class="badge-year">${escapeHtml(s.year)}</span></td>
                <td>
                    <span class="badge ${s.status === 'Active' ? 'bg-success-subtle text-success' : 'bg-secondary-subtle text-secondary'}">
                        ${escapeHtml(s.status || 'Active')}
                    </span>
                </td>
                <td><small class="text-muted">${formatDate(s.created_at)}</small></td>
                <td class="text-end">
                    <button class="btn btn-sm btn-outline-primary me-1" onclick="openEditModal('${s.student_id}')" title="Edit">
                        <i class="bi bi-pencil"></i>
                    </button>
                    <button class="btn btn-sm btn-outline-danger" onclick="openDeleteModal('${s.student_id}', '${escapeHtml(s.name)}')" title="Delete">
                        <i class="bi bi-trash"></i>
                    </button>
                </td>
            </tr>
        `;
    }).join('');
}

function renderRecentStudents(students) {
    const tbody = document.getElementById('recent-students-tbody');
    if (!tbody) return;

    const recent = students.slice(0, 5);
    if (recent.length === 0) {
        tbody.innerHTML = `<tr><td colspan="7" class="text-center py-3 text-muted">No recent records available.</td></tr>`;
        return;
    }

    tbody.innerHTML = recent.map(s => `
        <tr>
            <td>
                <div class="d-flex align-items-center gap-2">
                    <div class="student-avatar" style="width: 28px; height: 28px; font-size: 0.75rem;">${getInitials(s.name)}</div>
                    <span class="fw-semibold">${escapeHtml(s.name)}</span>
                </div>
            </td>
            <td><code>${escapeHtml(s.student_id)}</code></td>
            <td class="text-muted small">${escapeHtml(s.email)}</td>
            <td><span class="badge-dept">${escapeHtml(s.department)}</span></td>
            <td><span class="badge-year">${escapeHtml(s.year)}</span></td>
            <td><small class="text-muted">${formatDate(s.created_at)}</small></td>
            <td>
                <span class="badge ${s.status === 'Active' ? 'bg-success-subtle text-success' : 'bg-secondary'}">
                    ${escapeHtml(s.status || 'Active')}
                </span>
            </td>
        </tr>
    `).join('');
}

// ================= Add Student Handler =================
async function handleAddStudent(e) {
    e.preventDefault();

    const studentId = document.getElementById('add-student-id').value.trim();
    const name = document.getElementById('add-student-name').value.trim();
    const email = document.getElementById('add-student-email').value.trim();
    const phone = document.getElementById('add-student-phone').value.trim();
    const department = document.getElementById('add-student-department').value;
    const year = document.getElementById('add-student-year').value;
    const status = document.getElementById('add-student-status').value;

    const alertBox = document.getElementById('add-form-alert');
    const btnSubmit = document.getElementById('btn-submit-student');
    const spinner = document.getElementById('spinner-add-student');

    // Client-side quick check
    if (!studentId || !name || !email || !phone || !department || !year) {
        showFormAlert(alertBox, 'Please complete all required fields.', 'danger');
        return;
    }

    btnSubmit.disabled = true;
    spinner.classList.remove('d-none');
    alertBox.classList.add('d-none');

    const payload = {
        student_id: studentId,
        name: name,
        email: email,
        phone: phone,
        department: department,
        year: year,
        status: status
    };

    try {
        const response = await fetch('/api/students', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });

        const data = await response.json();

        if (!response.ok) {
            const msg = data.message || (data.errors ? data.errors.join(', ') : 'Failed to register student.');
            showFormAlert(alertBox, msg, 'danger');
            showToast(msg, 'error');
            return;
        }

        // Check if instruction says omit fetch (Simulating Bug APP-2: Frontend fetch not executed)
        if (data.frontend_instruction === 'omit_fetch_after_insert') {
            showToast(`[Simulated Bug] Student '${name}' processed, but frontend omitted reload!`, 'warning');
            showFormAlert(alertBox, `[Simulated Bug APP-2 Triggered]: Student record submitted, but loadStudents() was deliberately omitted! Check table to verify it does not appear until hard reload.`, 'warning');
            // Deliberately DO NOT call loadStudents()!
            updateMatrixCounters();
            return;
        }

        // Normal Healthy behavior:
        showToast(`Student '${name}' (${studentId}) registered successfully!`, 'success');
        document.getElementById('form-add-student').reset();
        
        // Auto-refresh student list & dashboard stats immediately
        await loadStudents();
        await loadDashboardStats();

        // Switch to student directory to view new record
        setTimeout(() => {
            switchView('students');
        }, 600);

    } catch (err) {
        showFormAlert(alertBox, `Network error: ${err.message}`, 'danger');
        showToast(err.message, 'error');
    } finally {
        btnSubmit.disabled = false;
        spinner.classList.add('d-none');
    }
}

// ================= Edit Student Handler =================
async function openEditModal(studentId) {
    try {
        const res = await fetch(`/api/students/${studentId}`);
        const data = await res.get_json ? await res.get_json() : await res.json();
        if (data.status !== 'success') {
            showToast('Student details could not be loaded.', 'error');
            return;
        }
        const s = data.student;
        document.getElementById('edit-student-id-orig').value = s.student_id;
        document.getElementById('edit-student-id').value = s.student_id;
        document.getElementById('edit-student-name').value = s.name;
        document.getElementById('edit-student-email').value = s.email;
        document.getElementById('edit-student-phone').value = s.phone;
        document.getElementById('edit-student-department').value = s.department;
        document.getElementById('edit-student-year').value = s.year;
        document.getElementById('edit-student-status').value = s.status || 'Active';

        const modal = new bootstrap.Modal(document.getElementById('modal-edit-student'));
        modal.show();
    } catch (e) {
        showToast(e.message, 'error');
    }
}

async function handleEditStudent(e) {
    e.preventDefault();
    const origId = document.getElementById('edit-student-id-orig').value;
    const payload = {
        student_id: origId,
        name: document.getElementById('edit-student-name').value.trim(),
        email: document.getElementById('edit-student-email').value.trim(),
        phone: document.getElementById('edit-student-phone').value.trim(),
        department: document.getElementById('edit-student-department').value,
        year: document.getElementById('edit-student-year').value,
        status: document.getElementById('edit-student-status').value
    };

    try {
        const res = await fetch(`/api/students/${origId}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });
        const data = await res.json();
        if (res.ok) {
            bootstrap.Modal.getInstance(document.getElementById('modal-edit-student')).hide();
            showToast(`Student '${origId}' updated successfully!`, 'success');
            loadStudents();
            loadDashboardStats();
        } else {
            showToast(data.message || 'Failed to update student.', 'error');
        }
    } catch (err) {
        showToast(err.message, 'error');
    }
}

// ================= Delete Student Handler =================
function openDeleteModal(studentId, name) {
    document.getElementById('delete-student-id').value = studentId;
    document.getElementById('delete-student-prompt').textContent = 
        `Are you sure you want to permanently delete '${name}' (${studentId})?`;
    const modal = new bootstrap.Modal(document.getElementById('modal-delete-student'));
    modal.show();
}

async function handleConfirmDelete() {
    const studentId = document.getElementById('delete-student-id').value;
    try {
        const res = await fetch(`/api/students/${studentId}`, { method: 'DELETE' });
        const data = await res.json();
        bootstrap.Modal.getInstance(document.getElementById('modal-delete-student')).hide();
        if (res.ok) {
            showToast(`Student '${studentId}' deleted.`, 'success');
            loadStudents();
            loadDashboardStats();
        } else {
            showToast(data.message || 'Failed to delete student.', 'error');
        }
    } catch (e) {
        showToast(e.message, 'error');
    }
}

// ================= Dashboard Stats & Charts =================
async function loadDashboardStats() {
    try {
        const res = await fetch('/api/stats');
        const json = await res.json();
        if (json.status !== 'success') return;

        const data = json.data;
        AppState.stats = data;

        document.getElementById('stat-total-students').textContent = data.total_students;
        document.getElementById('stat-total-departments').textContent = data.department_distribution.length;
        document.getElementById('stat-database-name').textContent = `DB: ${data.source_db || 'students.db'}`;

        renderCharts(data);
    } catch (err) {
        console.error("Failed to load statistics:", err);
    }
}

function renderCharts(stats) {
    if (!stats || !window.Chart) return;

    // 1. Department Bar Chart
    const deptCtx = document.getElementById('chart-departments');
    if (deptCtx) {
        const labels = stats.department_distribution.map(d => d.department);
        const counts = stats.department_distribution.map(d => d.count);

        if (AppState.charts.departments) {
            AppState.charts.departments.destroy();
        }

        AppState.charts.departments = new Chart(deptCtx, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Enrolled Students',
                    data: counts,
                    backgroundColor: '#2563eb',
                    borderRadius: 6,
                    maxBarThickness: 38
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: { legend: { display: false } },
                scales: {
                    y: { beginAtZero: true, ticks: { precision: 0 } },
                    x: { ticks: { font: { size: 10 } } }
                }
            }
        });
    }

    // 2. Academic Year Doughnut Chart
    const yearCtx = document.getElementById('chart-years');
    if (yearCtx) {
        const yearLabels = stats.year_distribution.map(y => y.year);
        const yearCounts = stats.year_distribution.map(y => y.count);

        if (AppState.charts.years) {
            AppState.charts.years.destroy();
        }

        AppState.charts.years = new Chart(yearCtx, {
            type: 'doughnut',
            data: {
                labels: yearLabels,
                datasets: [{
                    data: yearCounts,
                    backgroundColor: ['#3b82f6', '#06b6d4', '#10b981', '#f59e0b'],
                    borderWidth: 2,
                    borderColor: '#ffffff'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { position: 'bottom', labels: { boxWidth: 12, padding: 10, font: { size: 11 } } }
                }
            }
        });
    }
}

// ================= Search & Table Filtering =================
function filterStudentTable() {
    const search = document.getElementById('filter-search').value.toLowerCase().trim();
    const dept = document.getElementById('filter-department').value;
    const year = document.getElementById('filter-year').value;

    const filtered = AppState.students.filter(s => {
        const matchesSearch = !search || (
            s.name.toLowerCase().includes(search) ||
            s.student_id.toLowerCase().includes(search) ||
            s.email.toLowerCase().includes(search) ||
            s.department.toLowerCase().includes(search)
        );
        const matchesDept = !dept || s.department === dept;
        const matchesYear = !year || s.year === year;
        return matchesSearch && matchesDept && matchesYear;
    });

    renderStudentsTable(filtered);
}

// ================= Helper Utilities =================
function handleAutofillSample() {
    const randomPick = SAMPLE_STUDENT_POOL[Math.floor(Math.random() * SAMPLE_STUDENT_POOL.length)];
    const randomNum = Math.floor(100 + Math.random() * 899);
    
    document.getElementById('add-student-id').value = `STU-2024-${randomNum}`;
    document.getElementById('add-student-name').value = randomPick.name;
    document.getElementById('add-student-email').value = `${randomPick.name.toLowerCase().replace(/\s+/g, '.')}@example.edu`;
    document.getElementById('add-student-phone').value = randomPick.phone;
    document.getElementById('add-student-department').value = randomPick.dept;
    document.getElementById('add-student-year').value = randomPick.year;
    document.getElementById('add-student-status').value = 'Active';

    showToast('Sample student data filled!', 'info');
}

function generateNextStudentID() {
    const num = Math.floor(100 + Math.random() * 899);
    document.getElementById('add-student-id').value = `STU-2024-${num}`;
}

function exportStudentsToCSV() {
    if (!AppState.students || AppState.students.length === 0) {
        showToast('No student data to export.', 'warning');
        return;
    }

    const headers = ["ID", "Student ID", "Full Name", "Email", "Department", "Academic Year", "Phone Number", "Status", "Registered At"];
    const rows = AppState.students.map(s => [
        s.id,
        `"${s.student_id}"`,
        `"${s.name}"`,
        `"${s.email}"`,
        `"${s.department}"`,
        `"${s.year}"`,
        `"${s.phone}"`,
        `"${s.status || 'Active'}"`,
        `"${s.created_at || ''}"`
    ]);

    const csvContent = [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `students_export_${new Date().toISOString().slice(0,10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    showToast('Exported student directory to CSV.', 'success');
}

function showFormAlert(el, message, type) {
    if (!el) return;
    el.className = `alert alert-${type} mt-3`;
    el.textContent = message;
    el.classList.remove('d-none');
}

function showToast(message, type = 'info') {
    const container = document.getElementById('toast-container');
    if (!container) return;

    const toast = document.createElement('div');
    toast.className = `custom-toast toast-${type}`;
    
    const icons = {
        'success': 'bi-check-circle-fill text-success',
        'error': 'bi-exclamation-triangle-fill text-danger',
        'warning': 'bi-exclamation-circle-fill text-warning',
        'info': 'bi-info-circle-fill text-primary'
    };

    toast.innerHTML = `
        <i class="bi ${icons[type] || icons.info} fs-5"></i>
        <div class="flex-grow-1 small fw-semibold">${escapeHtml(message)}</div>
        <button type="button" class="btn-close btn-sm ms-2" onclick="this.parentElement.remove()"></button>
    `;

    container.appendChild(toast);
    setTimeout(() => {
        if (toast.parentElement) toast.remove();
    }, 4500);
}

function getInitials(name) {
    if (!name) return 'ST';
    const parts = name.trim().split(/\s+/);
    if (parts.length === 1) return parts[0].substring(0, 2).toUpperCase();
    return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
}

function formatDate(dateStr) {
    if (!dateStr) return 'Just now';
    try {
        const d = new Date(dateStr);
        return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
    } catch {
        return dateStr;
    }
}

function escapeHtml(text) {
    if (!text) return '';
    return String(text)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;');
}

function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}
