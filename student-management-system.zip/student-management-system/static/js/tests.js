/**
 * Student Management System - Live Automated Test Runner & Test Matrix UI
 * Executes all test suites from the browser and renders results.
 */

let allTestCases = [];
let activeCategoryFilter = 'ALL';

document.addEventListener('DOMContentLoaded', () => {
    initTestRunner();
});

function initTestRunner() {
    const btnRunTests = document.getElementById('btn-run-all-tests');
    if (btnRunTests) {
        btnRunTests.addEventListener('click', runAllTestsUI);
    }

    // Category filter pills
    const filterButtons = document.querySelectorAll('.filter-test-btn');
    filterButtons.forEach(btn => {
        btn.addEventListener('click', () => {
            filterButtons.forEach(b => {
                b.classList.remove('active', 'btn-dark');
                b.classList.add('btn-outline-secondary');
            });
            btn.classList.add('active', 'btn-dark');
            btn.classList.remove('btn-outline-secondary');

            activeCategoryFilter = btn.getAttribute('data-category');
            renderTestMatrixTable();
        });
    });
}

async function runAllTestsUI() {
    const btn = document.getElementById('btn-run-all-tests');
    const spinner = document.getElementById('spinner-tests');
    const tbody = document.getElementById('test-matrix-tbody');

    if (btn) btn.disabled = true;
    if (spinner) spinner.classList.remove('d-none');

    if (tbody) {
        tbody.innerHTML = `
            <tr>
                <td colspan="7" class="text-center py-5">
                    <div class="spinner-border text-primary mb-2" role="status"></div>
                    <div class="fw-bold">Executing 34 Test Cases across 6 Suites...</div>
                    <small class="text-muted">Unit, Database, REST API, Integration, Frontend Contracts, and E2E Workflows</small>
                </td>
            </tr>
        `;
    }

    try {
        const response = await fetch('/api/tests/run');
        const data = await response.json();

        if (data.status !== 'success') {
            throw new Error(data.message || 'Test runner failed.');
        }

        const report = data.test_results;
        allTestCases = report.test_cases || [];

        // Update Summary Cards
        document.getElementById('test-summary-total').textContent = report.total_tests;
        document.getElementById('test-summary-passed').textContent = report.total_passed;
        document.getElementById('test-summary-failed').textContent = report.total_failed;
        document.getElementById('test-pass-percent').textContent = `${report.pass_rate_percent}% Pass Rate`;
        document.getElementById('test-summary-duration').textContent = `${report.total_duration_ms} ms`;
        document.getElementById('test-last-run').textContent = `Last run: ${report.timestamp.split(' ')[1]}`;

        // Render matrix table
        renderTestMatrixTable();

        showToast(`Test suite complete: ${report.total_passed}/${report.total_tests} passed in ${report.total_duration_ms} ms!`, 
                  report.total_failed === 0 ? 'success' : 'error');

    } catch (err) {
        if (tbody) {
            tbody.innerHTML = `
                <tr>
                    <td colspan="7" class="text-center py-4 text-danger">
                        <i class="bi bi-x-circle-fill fs-4 d-block mb-2"></i>
                        Failed to execute tests: ${escapeHtml(err.message)}
                    </td>
                </tr>
            `;
        }
        showToast(err.message, 'error');
    } finally {
        if (btn) btn.disabled = false;
        if (spinner) spinner.classList.add('d-none');
    }
}

function renderTestMatrixTable() {
    const tbody = document.getElementById('test-matrix-tbody');
    if (!tbody) return;

    if (!allTestCases || allTestCases.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="7" class="text-center py-5 text-muted">
                    Click <strong>"Run Complete Test Suite"</strong> to execute all test cases.
                </td>
            </tr>
        `;
        return;
    }

    const filtered = activeCategoryFilter === 'ALL'
        ? allTestCases
        : allTestCases.filter(t => t.category === activeCategoryFilter);

    if (filtered.length === 0) {
        tbody.innerHTML = `<tr><td colspan="7" class="text-center py-4 text-muted">No tests found for category "${activeCategoryFilter}".</td></tr>`;
        return;
    }

    tbody.innerHTML = filtered.map(t => {
        const isPass = t.status === 'PASS';
        const statusBadge = isPass
            ? `<span class="badge bg-success-subtle text-success border border-success-subtle px-2 py-1"><i class="bi bi-check-circle-fill me-1"></i>PASS</span>`
            : `<span class="badge bg-danger-subtle text-danger border border-danger-subtle px-2 py-1"><i class="bi bi-x-circle-fill me-1"></i>FAIL</span>`;

        return `
            <tr>
                <td><code class="fw-bold text-dark">${escapeHtml(t.test_id)}</code></td>
                <td><span class="badge bg-light text-secondary border">${escapeHtml(t.category)}</span></td>
                <td><span class="fw-semibold">${escapeHtml(t.scenario)}</span></td>
                <td class="small text-muted">${escapeHtml(t.expected_result)}</td>
                <td class="small ${isPass ? 'text-success' : 'text-danger'}">${escapeHtml(t.actual_result)}</td>
                <td><span class="small font-monospace">${t.duration_ms} ms</span></td>
                <td class="text-center">${statusBadge}</td>
            </tr>
        `;
    }).join('');
}
