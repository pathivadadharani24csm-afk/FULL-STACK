"""
Student Management System - Flask Application & REST API
Features:
- Full student CRUD operations
- Comprehensive Dashboard statistics
- Bug simulation engine for database & application-level debugging
- Live 10-step diagnostic tools & direct DB inspection
- Live automated test suite runner
"""
import os
import re
import sqlite3
import traceback
from datetime import datetime
from flask import Flask, request, jsonify, render_template, send_from_directory

from config import Config
import database
from debug_controller import debug_controller

app = Flask(__name__, static_folder='static', template_folder='templates')
app.config.from_object(Config)

# Ensure databases are initialized on startup
with app.app_context():
    if not os.path.exists(Config.PRIMARY_DB_PATH):
        database.setup_all_databases()
        debug_controller.add_log("INFO", "Initialized primary, stale, and replica databases with seed data.")

# ----------------- Helper Functions -----------------

def validate_student_payload(data):
    """Validate student input payload."""
    errors = []
    required_fields = ["student_id", "name", "email", "department", "year", "phone"]
    for field in required_fields:
        if not data.get(field) or not str(data[field]).strip():
            errors.append(f"Field '{field}' is required and cannot be empty.")

    if "student_id" in data and data["student_id"]:
        sid = data["student_id"].strip()
        if not re.match(r"^STU-\d{4}-\d{3,4}$", sid):
            errors.append("Student ID must follow format 'STU-YYYY-NNN' (e.g., STU-2024-001).")

    if "email" in data and data["email"]:
        email = data["email"].strip()
        if not re.match(r"^[\w\.-]+@[\w\.-]+\.\w+$", email):
            errors.append("Invalid email format.")

    if "phone" in data and data["phone"]:
        phone_digits = re.sub(r"[^\d+]", "", data["phone"])
        if len(phone_digits) < 10:
            errors.append("Phone number must have at least 10 digits.")

    return errors

# ----------------- Frontend Page Routes -----------------

@app.route('/')
def index():
    """Render the primary single-page application dashboard."""
    return render_template('index.html')

# ----------------- Student REST API -----------------

@app.route('/api/health', methods=['GET'])
def health_check():
    return jsonify({
        "status": "healthy",
        "timestamp": datetime.now().isoformat(),
        "database_connected": os.path.exists(Config.PRIMARY_DB_PATH)
    })

@app.route('/api/students', methods=['GET'])
def get_students():
    """
    Fetch student list.
    Behavior adapts based on the active debugging scenario:
    - FIXED: returns all active students from primary DB.
    - DB_WRONG_CONNECTION: reads from stale DB.
    - DB_SPLIT_CONNECTION: reads from replica DB.
    - DB_FAULTY_SELECT: executes faulty SELECT WHERE status='Archived'.
    - DB_QUERY_CACHE: returns stale in-memory cached snapshot.
    - APP_STALE_RESPONSE: returns frozen static mock list.
    - APP_KEY_MISMATCH: returns key 'student_records' instead of 'students'.
    - APP_UNHANDLED_500: throws unhandled 500 error.
    """
    scenario = debug_controller.active_scenario
    debug_controller.add_log("INFO", f"GET /api/students called under scenario [{scenario}].")

    # Bug Simulation APP-5: Unhandled 500 error
    if scenario == "APP_UNHANDLED_500":
        debug_controller.add_log("ERROR", "SIMULATED BUG: Unhandled 500 Internal Server Error triggered during GET /api/students.")
        # Intentionally unhandled exception returning non-JSON or standard 500 HTML
        raise RuntimeError("SIMULATED BUG: Critical internal failure during record serialization!")

    # Bug Simulation APP-1: API Response Not Updated (static list)
    if scenario == "APP_STALE_RESPONSE":
        stale_static = [
            {"id": 1, "student_id": "STU-2024-001", "name": "Aarav Sharma", "email": "aarav.sharma@example.edu", "department": "Computer Science", "year": "3rd Year", "phone": "+91-98765-43210", "status": "Active"},
            {"id": 2, "student_id": "STU-2024-002", "name": "Priya Patel", "email": "priya.patel@example.edu", "department": "Information Technology", "year": "2nd Year", "phone": "+91-98765-43211", "status": "Active"}
        ]
        debug_controller.add_log("WARN", "SIMULATED BUG: Returning frozen static array instead of live database query.")
        return jsonify({
            "status": "success",
            "students": stale_static,
            "count": len(stale_static),
            "simulated_bug": "APP_STALE_RESPONSE"
        })

    # Bug Simulation DB-5: Query Cache without invalidation
    if scenario == "DB_QUERY_CACHE" and debug_controller.in_memory_cache is not None:
        debug_controller.add_log("WARN", f"SIMULATED BUG: Returning stale in-memory cache with {len(debug_controller.in_memory_cache)} records.")
        return jsonify({
            "status": "success",
            "students": debug_controller.in_memory_cache,
            "count": len(debug_controller.in_memory_cache),
            "cached": True,
            "simulated_bug": "DB_QUERY_CACHE"
        })

    # Determine target DB and Query
    target_db = Config.PRIMARY_DB_PATH
    custom_query = None

    if scenario == "DB_WRONG_CONNECTION":
        target_db = Config.STALE_DB_PATH
        debug_controller.add_log("WARN", f"SIMULATED BUG: Querying incorrect/stale database: {target_db}")
    elif scenario == "DB_SPLIT_CONNECTION":
        target_db = Config.REPLICA_DB_PATH
        debug_controller.add_log("WARN", f"SIMULATED BUG: Querying replica database instead of primary: {target_db}")
    elif scenario == "DB_FAULTY_SELECT":
        custom_query = "SELECT * FROM students WHERE status = 'Archived' ORDER BY id DESC"
        debug_controller.add_log("WARN", f"SIMULATED BUG: Executing faulty SELECT query: {custom_query}")

    students = database.get_all_students(db_path=target_db, custom_query=custom_query)

    # Optional search / department / year filtering from query params
    search = request.args.get('search', '').strip().lower()
    dept = request.args.get('department', '').strip()
    year = request.args.get('year', '').strip()

    filtered = students
    if search:
        filtered = [
            s for s in filtered
            if search in s['name'].lower() 
            or search in s['student_id'].lower()
            or search in s['email'].lower()
            or search in s['department'].lower()
        ]
    if dept:
        filtered = [s for s in filtered if s['department'] == dept]
    if year:
        filtered = [s for s in filtered if s['year'] == year]

    # Bug Simulation APP-4: Key Mismatch (returns 'student_records' instead of 'students')
    if scenario == "APP_KEY_MISMATCH":
        debug_controller.add_log("WARN", "SIMULATED BUG: Returning payload with mismatched key 'student_records' instead of 'students'.")
        return jsonify({
            "status": "success",
            "student_records": filtered,  # Misnamed key!
            "count": len(filtered),
            "simulated_bug": "APP_KEY_MISMATCH"
        })

    return jsonify({
        "status": "success",
        "students": filtered,
        "count": len(filtered),
        "source_db": os.path.basename(target_db)
    })

@app.route('/api/students/<student_id>', methods=['GET'])
def get_student(student_id):
    """Fetch single student details."""
    student = database.get_student_by_id(student_id, Config.PRIMARY_DB_PATH)
    if not student:
        return jsonify({"status": "error", "message": f"Student with ID '{student_id}' not found."}), 404
    return jsonify({"status": "success", "student": student})

@app.route('/api/students', methods=['POST'])
def add_student():
    """
    Insert a new student record.
    Behavior adapts based on the active debugging scenario:
    - FIXED: normal insertion with conn.commit() to primary DB.
    - DB_NO_COMMIT: inserts into cursor but omits conn.commit()!
    - DB_WRONG_CONNECTION: inserts into students_stale.db!
    - DB_QUERY_CACHE: inserts into primary DB, but omits invalidating the cache!
    """
    scenario = debug_controller.active_scenario
    data = request.get_json() or {}

    debug_controller.add_log("INFO", f"POST /api/students called under scenario [{scenario}].", {"student_id": data.get("student_id")})

    # Validate input
    errors = validate_student_payload(data)
    if errors:
        debug_controller.add_log("WARN", "Validation failed for student creation payload.", {"errors": errors})
        return jsonify({"status": "error", "message": "Validation failed.", "errors": errors}), 400

    # Determine commit and target DB
    target_db = Config.PRIMARY_DB_PATH
    auto_commit = True

    if scenario == "DB_NO_COMMIT":
        auto_commit = False
        debug_controller.add_log("ERROR", "SIMULATED BUG: Transaction NOT committed! Row executed on cursor, but conn.commit() omitted.")
    elif scenario == "DB_WRONG_CONNECTION":
        target_db = Config.STALE_DB_PATH
        debug_controller.add_log("WARN", f"SIMULATED BUG: Inserting record into stale database {target_db}")

    try:
        result = database.insert_student(data, db_path=target_db, auto_commit=auto_commit)
        
        # In FIXED mode, if cache scenario is not active, everything is fresh
        if scenario == "DB_QUERY_CACHE":
            debug_controller.add_log("WARN", "SIMULATED BUG: Record written to DB, but query cache was NOT invalidated!")
            # Cache deliberately not updated!

        new_student = {
            "id": result["id"],
            "student_id": data["student_id"],
            "name": data["name"],
            "email": data["email"],
            "department": data["department"],
            "year": data["year"],
            "phone": data["phone"],
            "status": data.get("status", "Active"),
            "committed_to_disk": result["committed"],
            "target_db": os.path.basename(target_db)
        }

        # Return 201 Created with student record
        return jsonify({
            "status": "success",
            "message": "Student record created successfully.",
            "student": new_student,
            "frontend_instruction": debug_controller.SCENARIOS[scenario]["frontend_behavior"]
        }), 201

    except sqlite3.IntegrityError as e:
        error_msg = str(e)
        debug_controller.add_log("ERROR", f"IntegrityError inserting student: {error_msg}")
        if "UNIQUE constraint failed: students.student_id" in error_msg:
            return jsonify({"status": "error", "message": f"Student ID '{data['student_id']}' already exists."}), 409
        elif "UNIQUE constraint failed: students.email" in error_msg:
            return jsonify({"status": "error", "message": f"Email '{data['email']}' is already registered."}), 409
        else:
            return jsonify({"status": "error", "message": f"Database integrity violation: {error_msg}"}), 409

    except Exception as e:
        debug_controller.add_log("ERROR", f"Unexpected error during student creation: {str(e)}")
        return jsonify({"status": "error", "message": f"Server error: {str(e)}"}), 500

@app.route('/api/students/<student_id>', methods=['PUT'])
def update_student_record(student_id):
    """Update student record."""
    data = request.get_json() or {}
    errors = validate_student_payload(data)
    if errors:
        return jsonify({"status": "error", "message": "Validation failed.", "errors": errors}), 400

    try:
        updated = database.update_student(student_id, data, Config.PRIMARY_DB_PATH)
        if not updated:
            return jsonify({"status": "error", "message": f"Student '{student_id}' not found."}), 404
        
        debug_controller.add_log("INFO", f"Updated student record '{student_id}'.")
        return jsonify({"status": "success", "message": f"Student '{student_id}' updated successfully."})
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route('/api/students/<student_id>', methods=['DELETE'])
def delete_student_record(student_id):
    """Delete student record."""
    deleted = database.delete_student(student_id, Config.PRIMARY_DB_PATH)
    if not deleted:
        return jsonify({"status": "error", "message": f"Student '{student_id}' not found."}), 404
    
    debug_controller.add_log("INFO", f"Deleted student record '{student_id}'.")
    return jsonify({"status": "success", "message": f"Student '{student_id}' deleted successfully."})

@app.route('/api/stats', methods=['GET'])
def get_stats():
    """Compute and return dashboard statistics."""
    scenario = debug_controller.active_scenario
    target_db = Config.PRIMARY_DB_PATH
    custom_query = None

    if scenario == "DB_WRONG_CONNECTION":
        target_db = Config.STALE_DB_PATH
    elif scenario == "DB_SPLIT_CONNECTION":
        target_db = Config.REPLICA_DB_PATH
    elif scenario == "DB_FAULTY_SELECT":
        custom_query = "SELECT COUNT(*) AS total FROM students WHERE status = 'Archived'"

    try:
        stats = database.get_statistics(target_db, custom_query)
        stats["active_scenario"] = scenario
        stats["source_db"] = os.path.basename(target_db)
        return jsonify({"status": "success", "data": stats})
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

# ----------------- Debugging & Diagnostics API -----------------

@app.route('/api/debug/status', methods=['GET'])
def get_debug_status():
    """Return active scenario details, all scenarios, and 10-step guide."""
    return jsonify({
        "status": "success",
        "current_scenario": debug_controller.get_current_scenario_info(),
        "all_scenarios": debug_controller.get_all_scenarios(),
        "ten_step_procedure": debug_controller.TEN_STEP_PROCEDURE,
        "database_summary": database.get_raw_database_summary()
    })

@app.route('/api/debug/set-scenario', methods=['POST'])
def set_debug_scenario():
    """Set active debugging scenario."""
    data = request.get_json() or {}
    scenario_id = data.get('scenario_id')
    success, info = debug_controller.set_scenario(scenario_id)
    if not success:
        return jsonify({"status": "error", "message": f"Unknown scenario ID '{scenario_id}'."}), 400
    return jsonify({
        "status": "success",
        "message": f"Switched to scenario: {info['name']}",
        "scenario": info
    })

@app.route('/api/debug/reset-scenario', methods=['POST'])
def reset_debug_scenario():
    """Reset to FIXED (Healthy baseline)."""
    debug_controller.reset_to_fixed()
    return jsonify({
        "status": "success",
        "message": "System restored to FIXED (Healthy) mode.",
        "current_scenario": debug_controller.get_current_scenario_info()
    })

@app.route('/api/debug/inspect-db', methods=['GET'])
def inspect_database_files():
    """
    Directly query SQLite files on disk and return row counts and records.
    Crucial for Step 2 of debugging: 'Check whether records are inserted into the database'.
    """
    summary = database.get_raw_database_summary()
    
    # Also fetch all rows directly from primary DB
    primary_students = database.get_all_students(Config.PRIMARY_DB_PATH)
    stale_students = database.get_all_students(Config.STALE_DB_PATH) if os.path.exists(Config.STALE_DB_PATH) else []
    replica_students = database.get_all_students(Config.REPLICA_DB_PATH) if os.path.exists(Config.REPLICA_DB_PATH) else []

    return jsonify({
        "status": "success",
        "disk_databases": summary,
        "primary_db_records": primary_students,
        "stale_db_records": stale_students,
        "replica_db_records": replica_students,
        "active_scenario": debug_controller.active_scenario
    })

@app.route('/api/debug/logs', methods=['GET'])
def get_debug_logs():
    """Return backend execution logs."""
    limit = int(request.args.get('limit', 50))
    return jsonify({
        "status": "success",
        "logs": debug_controller.get_logs(limit)
    })

@app.route('/api/debug/clear-logs', methods=['POST'])
def clear_debug_logs():
    """Clear backend log buffer."""
    debug_controller.clear_logs()
    return jsonify({"status": "success", "message": "Logs cleared successfully."})

@app.route('/api/debug/reset-database', methods=['POST'])
def reset_database():
    """Re-initialize and re-seed all database files."""
    database.setup_all_databases()
    debug_controller.reset_to_fixed()
    debug_controller.add_log("INFO", "All databases reset and re-seeded with sample data.")
    return jsonify({"status": "success", "message": "Databases re-initialized with sample data."})

# ----------------- Automated Test Runner API -----------------

@app.route('/api/tests/run', methods=['GET', 'POST'])
def run_tests_endpoint():
    """
    Execute the test runner suite dynamically and return JSON results.
    """
    from test_runner import run_all_tests
    results = run_all_tests()
    return jsonify({
        "status": "success",
        "test_results": results
    })

# ----------------- Global Error Handlers -----------------

@app.errorhandler(404)
def not_found_error(error):
    if request.path.startswith('/api/'):
        return jsonify({"status": "error", "message": f"Endpoint '{request.path}' not found."}), 404
    return render_template('index.html'), 200

@app.errorhandler(500)
def internal_error(error):
    debug_controller.add_log("ERROR", f"Internal Server Error: {str(error)}")
    # If the active scenario is APP_UNHANDLED_500, we intentionally return HTML or raw 500
    if debug_controller.active_scenario == "APP_UNHANDLED_500":
        return "<!doctype html><html><head><title>500 Internal Server Error</title></head><body><h1>Internal Server Error</h1><p>Simulated unhandled server exception without JSON wrapper!</p></body></html>", 500
    
    return jsonify({
        "status": "error",
        "message": "Internal server error occurred.",
        "details": str(error)
    }), 500

if __name__ == '__main__':
    print(f"Starting Student Management System on http://{Config.HOST}:{Config.PORT}")
    app.run(host=Config.HOST, port=Config.PORT, debug=Config.DEBUG)
