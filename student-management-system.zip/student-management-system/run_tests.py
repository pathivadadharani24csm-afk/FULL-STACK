#!/usr/bin/env python3
"""
CLI Test Runner for Student Management System.
Runs all unit, database, api, integration, frontend, and e2e test cases
and prints a formatted terminal matrix.
"""
import sys
from test_runner import run_all_tests

def main():
    print("=" * 100)
    print("  STUDENT MANAGEMENT SYSTEM - AUTOMATED TEST SUITE EXECUTION")
    print("=" * 100)
    
    report = run_all_tests()

    print(f"\nExecution Timestamp: {report['timestamp']}")
    print(f"Total Tests Run   : {report['total_tests']}")
    print(f"Total Passed      : {report['total_passed']}")
    print(f"Total Failed      : {report['total_failed']}")
    print(f"Pass Rate         : {report['pass_rate_percent']}%")
    print(f"Total Duration    : {report['total_duration_ms']} ms\n")

    print("-" * 100)
    print(f"{'Test ID':<13} | {'Category':<18} | {'Scenario':<42} | {'Time (ms)':<9} | {'Status'}")
    print("-" * 100)

    for tc in report["test_cases"]:
        status_label = f"[\033[92mPASS\033[0m]" if tc["status"] == "PASS" else f"[\033[91mFAIL\033[0m]"
        scenario_short = (tc["scenario"][:39] + '...') if len(tc["scenario"]) > 42 else tc["scenario"]
        print(f"{tc['test_id']:<13} | {tc['category']:<18} | {scenario_short:<42} | {tc['duration_ms']:<9} | {status_label}")

    print("-" * 100)
    print("\nCategory Breakdown:")
    for cat, counts in report["categories"].items():
        print(f"  • {cat:<22}: {counts['pass']}/{counts['total']} Passed ({round(counts['pass']/counts['total']*100)}%)")
    print("=" * 100)

    if report["total_failed"] > 0:
        sys.exit(1)
    else:
        print("\nAll tests passed successfully!")
        sys.exit(0)

if __name__ == '__main__':
    main()
