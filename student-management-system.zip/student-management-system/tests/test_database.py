"""
Database Testing for Student Management System.
Validates SQLite connections, schemas, ACID transaction commit vs rollback,
constraints, queries, and statistics aggregation.
"""
import os
import sqlite3
import unittest
import tempfile
from database import init_db, insert_student, get_all_students, get_student_by_id, update_student, delete_student, get_statistics

class TestDatabase(unittest.TestCase):
    """TC-DB test suite."""

    def setUp(self):
        # Create a temporary database for test isolation
        self.temp_db_fd, self.temp_db_path = tempfile.mkstemp(suffix=".db")
        init_db(self.temp_db_path, reset=True)

        self.sample_student = {
            "student_id": "STU-2024-501",
            "name": "Tanvi Sen",
            "email": "tanvi.sen@example.edu",
            "department": "Computer Science",
            "year": "2nd Year",
            "phone": "+91-98765-43301",
            "status": "Active"
        }

    def tearDown(self):
        os.close(self.temp_db_fd)
        if os.path.exists(self.temp_db_path):
            try:
                os.remove(self.temp_db_path)
            except OSError:
                pass

    def test_tc_db_001_insert_and_commit_persistence(self):
        """TC-DB-001: Verify record is persisted when transaction is committed."""
        result = insert_student(self.sample_student, db_path=self.temp_db_path, auto_commit=True)
        self.assertTrue(result["committed"])
        
        # Verify persistence with a new connection
        stored = get_student_by_id("STU-2024-501", db_path=self.temp_db_path)
        self.assertIsNotNone(stored)
        self.assertEqual(stored["name"], "Tanvi Sen")
        self.assertEqual(stored["department"], "Computer Science")

    def test_tc_db_002_uncommitted_transaction_rollback(self):
        """TC-DB-002: Verify record is NOT persisted when transaction is uncommitted."""
        # Intentionally do not commit (simulate DB_NO_COMMIT bug)
        result = insert_student(self.sample_student, db_path=self.temp_db_path, auto_commit=False)
        self.assertFalse(result["committed"])

        # Check with fresh connection: record should not exist on disk!
        stored = get_student_by_id("STU-2024-501", db_path=self.temp_db_path)
        self.assertIsNone(stored, "Record should not exist in database because transaction was not committed!")

    def test_tc_db_003_unique_student_id_constraint(self):
        """TC-DB-003: Enforce unique constraint on student_id."""
        insert_student(self.sample_student, db_path=self.temp_db_path, auto_commit=True)
        
        # Try inserting duplicate student_id with different email
        duplicate_student = dict(self.sample_student)
        duplicate_student["email"] = "different.email@example.edu"
        
        with self.assertRaises(sqlite3.IntegrityError):
            insert_student(duplicate_student, db_path=self.temp_db_path, auto_commit=True)

    def test_tc_db_004_unique_email_constraint(self):
        """TC-DB-004: Enforce unique constraint on email."""
        insert_student(self.sample_student, db_path=self.temp_db_path, auto_commit=True)
        
        # Try inserting duplicate email with different student_id
        duplicate_email_student = dict(self.sample_student)
        duplicate_email_student["student_id"] = "STU-2024-502"
        
        with self.assertRaises(sqlite3.IntegrityError):
            insert_student(duplicate_email_student, db_path=self.temp_db_path, auto_commit=True)

    def test_tc_db_005_update_record(self):
        """TC-DB-005: Successfully update existing student record."""
        insert_student(self.sample_student, db_path=self.temp_db_path, auto_commit=True)
        
        updated_data = dict(self.sample_student)
        updated_data["name"] = "Tanvi Sen Sharma"
        updated_data["department"] = "Data Science"
        
        success = update_student("STU-2024-501", updated_data, db_path=self.temp_db_path)
        self.assertTrue(success)
        
        stored = get_student_by_id("STU-2024-501", db_path=self.temp_db_path)
        self.assertEqual(stored["name"], "Tanvi Sen Sharma")
        self.assertEqual(stored["department"], "Data Science")

    def test_tc_db_006_delete_record(self):
        """TC-DB-006: Successfully delete student record."""
        insert_student(self.sample_student, db_path=self.temp_db_path, auto_commit=True)
        self.assertIsNotNone(get_student_by_id("STU-2024-501", db_path=self.temp_db_path))
        
        success = delete_student("STU-2024-501", db_path=self.temp_db_path)
        self.assertTrue(success)
        self.assertIsNone(get_student_by_id("STU-2024-501", db_path=self.temp_db_path))

    def test_tc_db_007_statistics_calculation(self):
        """TC-DB-007: Correct calculation of dashboard statistics."""
        insert_student(self.sample_student, db_path=self.temp_db_path, auto_commit=True)
        
        second_student = {
            "student_id": "STU-2024-502",
            "name": "Manish Paul",
            "email": "manish.p@example.edu",
            "department": "Civil Engineering",
            "year": "1st Year",
            "phone": "+91-98765-43302",
            "status": "Active"
        }
        insert_student(second_student, db_path=self.temp_db_path, auto_commit=True)
        
        stats = get_statistics(db_path=self.temp_db_path)
        self.assertEqual(stats["total_students"], 2)
        self.assertEqual(len(stats["department_distribution"]), 2)
        self.assertEqual(len(stats["year_distribution"]), 2)

if __name__ == '__main__':
    unittest.main()
