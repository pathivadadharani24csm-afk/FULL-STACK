"""
Integration Tests for Student Management System.
Validates multi-component interactions between Flask Controllers,
Database Files, Transaction Management, and Debug Scenarios.
"""
import json
import unittest
from app import app
from config import Config
import database
from debug_controller import debug_controller

class TestIntegration(unittest.TestCase):
    """TC-INT test suite."""

    @classmethod
    def setUpClass(cls):
        app.config['TESTING'] = True
        cls.client = app.test_client()

    def setUp(self):
        database.setup_all_databases()
        debug_controller.reset_to_fixed()

    def tearDown(self):
        debug_controller.reset_to_fixed()

    def test_tc_int_001_db_no_commit_discrepancy(self):
        """TC-INT-001: Integration test for DB_NO_COMMIT bug scenario."""
        # Enable uncommitted transaction scenario
        self.client.post('/api/debug/set-scenario',
                         data=json.dumps({"scenario_id": "DB_NO_COMMIT"}),
                         content_type='application/json')

        # Add a student
        payload = {
            "student_id": "STU-2024-777",
            "name": "Ghost Student",
            "email": "ghost.student@example.edu",
            "department": "Computer Science",
            "year": "2nd Year",
            "phone": "+91-98765-43777"
        }
        res = self.client.post('/api/students',
                               data=json.dumps(payload),
                               content_type='application/json')
        self.assertEqual(res.status_code, 201)

        # Direct database query check: Record must NOT exist on disk!
        disk_student = database.get_student_by_id("STU-2024-777", Config.PRIMARY_DB_PATH)
        self.assertIsNone(disk_student, "Record was rolled back because commit was missing!")

        # API query check: Record must NOT be returned!
        get_res = self.client.get('/api/students')
        students = get_res.get_json()["students"]
        self.assertFalse(any(s["student_id"] == "STU-2024-777" for s in students))

    def test_tc_int_002_split_database_discrepancy(self):
        """TC-INT-002: Integration test for DB_SPLIT_CONNECTION (Insert to Primary, Read Replica)."""
        self.client.post('/api/debug/set-scenario',
                         data=json.dumps({"scenario_id": "DB_SPLIT_CONNECTION"}),
                         content_type='application/json')

        payload = {
            "student_id": "STU-2024-778",
            "name": "Replica Desync Student",
            "email": "replica.student@example.edu",
            "department": "Information Technology",
            "year": "3rd Year",
            "phone": "+91-98765-43778"
        }
        # Insert
        res = self.client.post('/api/students',
                               data=json.dumps(payload),
                               content_type='application/json')
        self.assertEqual(res.status_code, 201)

        # Primary DB actually HAS the record:
        primary_record = database.get_student_by_id("STU-2024-778", Config.PRIMARY_DB_PATH)
        self.assertIsNotNone(primary_record)

        # But GET API reads from replica DB which does NOT have it:
        get_res = self.client.get('/api/students')
        students = get_res.get_json()["students"]
        self.assertFalse(any(s["student_id"] == "STU-2024-778" for s in students))

    def test_tc_int_003_faulty_select_discrepancy(self):
        """TC-INT-003: Integration test for DB_FAULTY_SELECT (Where clause filters out active students)."""
        self.client.post('/api/debug/set-scenario',
                         data=json.dumps({"scenario_id": "DB_FAULTY_SELECT"}),
                         content_type='application/json')

        payload = {
            "student_id": "STU-2024-779",
            "name": "Filtered Out Student",
            "email": "filtered.student@example.edu",
            "department": "Civil Engineering",
            "year": "1st Year",
            "phone": "+91-98765-43779"
        }
        self.client.post('/api/students',
                         data=json.dumps(payload),
                         content_type='application/json')

        # Record is in Primary DB:
        self.assertIsNotNone(database.get_student_by_id("STU-2024-779", Config.PRIMARY_DB_PATH))

        # But GET API returns 0 students because query only selects Archived!
        get_res = self.client.get('/api/students')
        students = get_res.get_json()["students"]
        self.assertEqual(len(students), 0)

    def test_tc_int_004_fix_and_restore_healthy_state(self):
        """TC-INT-004: Verifies resetting to FIXED restores normal operation and displays students."""
        # First induce fault
        self.client.post('/api/debug/set-scenario',
                         data=json.dumps({"scenario_id": "DB_FAULTY_SELECT"}),
                         content_type='application/json')
        
        # Now reset to FIXED
        reset_res = self.client.post('/api/debug/reset-scenario')
        self.assertEqual(reset_res.status_code, 200)

        # Add a student in FIXED mode
        payload = {
            "student_id": "STU-2024-780",
            "name": "Healthy Flow Student",
            "email": "healthy.student@example.edu",
            "department": "Data Science",
            "year": "4th Year",
            "phone": "+91-98765-43780"
        }
        post_res = self.client.post('/api/students',
                                    data=json.dumps(payload),
                                    content_type='application/json')
        self.assertEqual(post_res.status_code, 201)

        # Now both DB and GET API reflect the new student immediately!
        get_res = self.client.get('/api/students')
        students = get_res.get_json()["students"]
        self.assertTrue(any(s["student_id"] == "STU-2024-780" for s in students))

if __name__ == '__main__':
    unittest.main()
