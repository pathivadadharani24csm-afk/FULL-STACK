"""
Frontend Contract Tests for Student Management System.
Validates client-side data contracts, JSON schema structures,
search/filter parameters, and response headers required by frontend scripts.
"""
import json
import unittest
from app import app
import database
from debug_controller import debug_controller

class TestFrontendContracts(unittest.TestCase):
    """TC-FE test suite."""

    @classmethod
    def setUpClass(cls):
        app.config['TESTING'] = True
        cls.client = app.test_client()

    def setUp(self):
        database.setup_all_databases()
        debug_controller.reset_to_fixed()

    def test_tc_fe_001_json_content_type_headers(self):
        """TC-FE-001: Ensure all API endpoints return application/json Content-Type."""
        endpoints = ['/api/students', '/api/stats', '/api/debug/status', '/api/debug/logs']
        for ep in endpoints:
            res = self.client.get(ep)
            self.assertIn('application/json', res.content_type, f"Endpoint {ep} did not return JSON header.")

    def test_tc_fe_002_student_payload_contract_keys(self):
        """TC-FE-002: Student objects must contain all keys expected by frontend table renderer."""
        res = self.client.get('/api/students')
        data = res.get_json()
        students = data.get("students", [])
        self.assertGreater(len(students), 0)

        required_keys = ["id", "student_id", "name", "email", "department", "year", "phone", "status"]
        first_student = students[0]
        for key in required_keys:
            self.assertIn(key, first_student, f"Missing required UI key: '{key}' in student record.")

    def test_tc_fe_003_search_query_filtering(self):
        """TC-FE-003: Frontend search filter query param works correctly."""
        # Query for 'Aarav'
        res = self.client.get('/api/students?search=Aarav')
        data = res.get_json()
        self.assertEqual(data["status"], "success")
        self.assertEqual(len(data["students"]), 1)
        self.assertEqual(data["students"][0]["name"], "Aarav Sharma")

    def test_tc_fe_004_department_filtering(self):
        """TC-FE-004: Frontend department filter query param works correctly."""
        res = self.client.get('/api/students?department=Computer Science')
        data = res.get_json()
        self.assertEqual(data["status"], "success")
        for s in data["students"]:
            self.assertEqual(s["department"], "Computer Science")

    def test_tc_fe_005_year_filtering(self):
        """TC-FE-005: Frontend year filter query param works correctly."""
        res = self.client.get('/api/students?year=1st Year')
        data = res.get_json()
        self.assertEqual(data["status"], "success")
        for s in data["students"]:
            self.assertEqual(s["year"], "1st Year")

if __name__ == '__main__':
    unittest.main()
