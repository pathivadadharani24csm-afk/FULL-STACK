"""
Unit Tests for Student Management System.
Validates input sanitization, data validation helpers, and business logic.
"""
import re
import unittest

def validate_student_data(data):
    """Business logic validator for student creation/update."""
    errors = []
    
    # Required fields
    required = ["student_id", "name", "email", "department", "year", "phone"]
    for field in required:
        if not data.get(field) or not str(data[field]).strip():
            errors.append(f"Field '{field}' is required.")

    # Student ID format (e.g. STU-2024-XXX or alphanumeric)
    if "student_id" in data and data["student_id"]:
        if not re.match(r"^STU-\d{4}-\d{3,4}$", data["student_id"].strip()):
            errors.append("Student ID must follow format 'STU-YYYY-NNN' (e.g., STU-2024-001).")

    # Email format
    if "email" in data and data["email"]:
        if not re.match(r"^[\w\.-]+@[\w\.-]+\.\w+$", data["email"].strip()):
            errors.append("Invalid email address format.")

    # Phone number length / characters
    if "phone" in data and data["phone"]:
        cleaned = re.sub(r"[^\d+]", "", data["phone"])
        if len(cleaned) < 10:
            errors.append("Phone number must have at least 10 digits.")

    # Allowed departments
    allowed_departments = [
        "Computer Science",
        "Information Technology",
        "Electrical Engineering",
        "Mechanical Engineering",
        "Civil Engineering",
        "Data Science"
    ]
    if "department" in data and data["department"] not in allowed_departments:
        errors.append(f"Invalid department '{data['department']}'.")

    # Allowed years
    allowed_years = ["1st Year", "2nd Year", "3rd Year", "4th Year"]
    if "year" in data and data["year"] not in allowed_years:
        errors.append(f"Invalid academic year '{data['year']}'.")

    return len(errors) == 0, errors


class TestStudentUnit(unittest.TestCase):
    """TC-UNIT test suite."""

    def test_tc_unit_001_valid_student_data(self):
        """TC-UNIT-001: Validate correct student data passes validation."""
        valid_data = {
            "student_id": "STU-2024-101",
            "name": "Arjun Verma",
            "email": "arjun.verma@example.edu",
            "department": "Computer Science",
            "year": "2nd Year",
            "phone": "+91-98765-43220",
            "status": "Active"
        }
        is_valid, errors = validate_student_data(valid_data)
        self.assertTrue(is_valid, f"Validation failed unexpectedly: {errors}")
        self.assertEqual(len(errors), 0)

    def test_tc_unit_002_missing_required_fields(self):
        """TC-UNIT-002: Detect missing required fields."""
        incomplete_data = {
            "student_id": "STU-2024-102",
            "name": "",
            "email": "test@example.edu"
        }
        is_valid, errors = validate_student_data(incomplete_data)
        self.assertFalse(is_valid)
        self.assertTrue(any("name" in e for e in errors))
        self.assertTrue(any("department" in e for e in errors))

    def test_tc_unit_003_invalid_student_id_format(self):
        """TC-UNIT-003: Reject invalid student ID format."""
        invalid_id_data = {
            "student_id": "INVALID_ID_123",
            "name": "Rahul Roy",
            "email": "rahul.roy@example.edu",
            "department": "Mechanical Engineering",
            "year": "1st Year",
            "phone": "+91-98765-43221"
        }
        is_valid, errors = validate_student_data(invalid_id_data)
        self.assertFalse(is_valid)
        self.assertTrue(any("Student ID must follow format" in e for e in errors))

    def test_tc_unit_004_invalid_email_format(self):
        """TC-UNIT-004: Reject malformed email address."""
        bad_email = {
            "student_id": "STU-2024-104",
            "name": "Kavita Rao",
            "email": "not-an-email",
            "department": "Information Technology",
            "year": "3rd Year",
            "phone": "+91-98765-43222"
        }
        is_valid, errors = validate_student_data(bad_email)
        self.assertFalse(is_valid)
        self.assertTrue(any("email" in e.lower() for e in errors))

    def test_tc_unit_005_invalid_department(self):
        """TC-UNIT-005: Reject non-existent department choice."""
        bad_dept = {
            "student_id": "STU-2024-105",
            "name": "Sunil Kumar",
            "email": "sunil.kumar@example.edu",
            "department": "Aeronautical Alchemy",
            "year": "4th Year",
            "phone": "+91-98765-43223"
        }
        is_valid, errors = validate_student_data(bad_dept)
        self.assertFalse(is_valid)
        self.assertTrue(any("department" in e.lower() for e in errors))

if __name__ == '__main__':
    unittest.main()
