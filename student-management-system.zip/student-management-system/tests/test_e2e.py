"""
End-to-End (E2E) Workflow Tests for Student Management System.
Simulates real user workflows:
1. Dashboard opening and stats inspection
2. Student registration
3. Database confirmation
4. Immediate table list display
5. Simulated failure demonstration (record inserted/attempted but not displayed)
6. Problem root-cause identification
7. Bug fix application
8. Retesting and validation of recovery
"""
import json
import unittest
from app import app
from config import Config
import database
from debug_controller import debug_controller

class TestE2EWorkflow(unittest.TestCase):
    """TC-E2E test suite."""

    @classmethod
    def setUpClass(cls):
        app.config['TESTING'] = True
        cls.client = app.test_client()

    def setUp(self):
        database.setup_all_databases()
        debug_controller.reset_to_fixed()

    def test_tc_e2e_001_complete_successful_workflow(self):
        """
        TC-E2E-001: Complete successful lifecycle:
        1. Open dashboard (check initial count)
        2. Add new student
        3. Confirm record is saved in database directly
        4. Open student list API
        5. Verify new student is displayed immediately
        6. Verify stats increased by 1
        """
        # Step 1: Check initial stats
        res_initial_stats = self.client.get('/api/stats')
        initial_count = res_initial_stats.get_json()["data"]["total_students"]
        self.assertEqual(initial_count, 8)

        # Step 2: Add new student
        new_student_data = {
            "student_id": "STU-2024-999",
            "name": "Kunal Deshmukh",
            "email": "kunal.d@example.edu",
            "department": "Computer Science",
            "year": "2nd Year",
            "phone": "+91-98765-43999",
            "status": "Active"
        }
        res_add = self.client.post('/api/students',
                                   data=json.dumps(new_student_data),
                                   content_type='application/json')
        self.assertEqual(res_add.status_code, 201)

        # Step 3: Confirm saved in SQLite database directly
        db_student = database.get_student_by_id("STU-2024-999", Config.PRIMARY_DB_PATH)
        self.assertIsNotNone(db_student, "Student must be saved to disk database!")
        self.assertEqual(db_student["name"], "Kunal Deshmukh")

        # Step 4 & 5: Open student list and verify displayed immediately
        res_list = self.client.get('/api/students')
        students = res_list.get_json()["students"]
        found = [s for s in students if s["student_id"] == "STU-2024-999"]
        self.assertEqual(len(found), 1, "New student must be present in the student list!")

        # Step 6: Verify stats increased by 1
        res_updated_stats = self.client.get('/api/stats')
        new_count = res_updated_stats.get_json()["data"]["total_students"]
        self.assertEqual(new_count, initial_count + 1)

    def test_tc_e2e_002_failure_simulation_and_fix_workflow(self):
        """
        TC-E2E-002: Problem Demonstration, Diagnosis, Fix & Retest Workflow:
        1. Inject simulated bug (DB_NO_COMMIT)
        2. Attempt adding a student
        3. Observe failure: Record was NOT persisted to database
        4. Diagnose root cause: Missing conn.commit()
        5. Apply fix (Reset to FIXED mode)
        6. Retest: Add student again, verify persistence & immediate display
        """
        # Step 1: Inject simulated bug
        self.client.post('/api/debug/set-scenario',
                         data=json.dumps({"scenario_id": "DB_NO_COMMIT"}),
                         content_type='application/json')
        
        # Step 2: Attempt adding a student
        buggy_student = {
            "student_id": "STU-2024-000",
            "name": "Uncommitted Student",
            "email": "uncommitted@example.edu",
            "department": "Mechanical Engineering",
            "year": "1st Year",
            "phone": "+91-98765-43000"
        }
        res_buggy_add = self.client.post('/api/students',
                                         data=json.dumps(buggy_student),
                                         content_type='application/json')
        self.assertEqual(res_buggy_add.status_code, 201)

        # Step 3: Observe failure: NOT in database disk file
        disk_record = database.get_student_by_id("STU-2024-000", Config.PRIMARY_DB_PATH)
        self.assertIsNone(disk_record, "Simulated Bug Verified: Record was not committed to database disk!")

        # Step 4: Check student list: student is NOT displayed
        res_list = self.client.get('/api/students')
        students = res_list.get_json()["students"]
        self.assertFalse(any(s["student_id"] == "STU-2024-000" for s in students))

        # Step 5: Apply fix (Switch back to FIXED mode)
        res_fix = self.client.post('/api/debug/reset-scenario')
        self.assertEqual(res_fix.status_code, 200)

        # Step 6: Retest application under fixed mode
        res_fixed_add = self.client.post('/api/students',
                                         data=json.dumps(buggy_student),
                                         content_type='application/json')
        self.assertEqual(res_fixed_add.status_code, 201)

        # Confirm database now HAS the student
        fixed_record = database.get_student_by_id("STU-2024-000", Config.PRIMARY_DB_PATH)
        self.assertIsNotNone(fixed_record, "Fixed Application Verified: Record now persists in database!")

        # Confirm student list displays the student immediately
        res_fixed_list = self.client.get('/api/students')
        students_after_fix = res_fixed_list.get_json()["students"]
        self.assertTrue(any(s["student_id"] == "STU-2024-000" for s in students_after_fix))

if __name__ == '__main__':
    unittest.main()
