"""
Integration & REST API Tests for Student Management System.
Validates all endpoints, HTTP status codes, payloads, error responses,
and debugging status endpoints using Flask test_client.
"""
import json
import unittest
from app import app
from config import Config
import database
from debug_controller import debug_controller

class TestAPI(unittest.TestCase):
    """TC-API test suite."""

    @classmethod
    def setUpClass(cls):
        app.config['TESTING'] = True
        cls.client = app.test_client()

    def setUp(self):
        # Reset database and ensure FIXED healthy mode before each test
        database.setup_all_databases()
        debug_controller.reset_to_fixed()

    def test_tc_api_001_health_check(self):
        """TC-API-001: GET /api/health returns 200 and healthy status."""
        res = self.client.get('/api/health')
        self.assertEqual(res.status_code, 200)
        data = res.get_json()
        self.assertEqual(data["status"], "healthy")
        self.assertTrue(data["database_connected"])

    def test_tc_api_002_get_students_list(self):
        """TC-API-002: GET /api/students returns 200 and array of students."""
        res = self.client.get('/api/students')
        self.assertEqual(res.status_code, 200)
        data = res.get_json()
        self.assertEqual(data["status"], "success")
        self.assertIn("students", data)
        self.assertGreaterEqual(len(data["students"]), 8)

    def test_tc_api_003_post_student_success(self):
        """TC-API-003: POST /api/students creates record and returns 201 Created."""
        payload = {
            "student_id": "STU-2024-888",
            "name": "Nandini Sen",
            "email": "nandini.sen@example.edu",
            "department": "Computer Science",
            "year": "3rd Year",
            "phone": "+91-98765-43888",
            "status": "Active"
        }
        res = self.client.post('/api/students',
                               data=json.dumps(payload),
                               content_type='application/json')
        self.assertEqual(res.status_code, 201)
        data = res.get_json()
        self.assertEqual(data["status"], "success")
        self.assertEqual(data["student"]["student_id"], "STU-2024-888")

        # Verify it appears in subsequent GET request
        get_res = self.client.get('/api/students')
        students = get_res.get_json()["students"]
        matching = [s for s in students if s["student_id"] == "STU-2024-888"]
        self.assertEqual(len(matching), 1)

    def test_tc_api_004_post_student_validation_error(self):
        """TC-API-004: POST /api/students with invalid data returns 400 Bad Request."""
        invalid_payload = {
            "student_id": "STU-2024-889",
            "name": "", # Empty name
            "email": "not-valid-email"
        }
        res = self.client.post('/api/students',
                               data=json.dumps(invalid_payload),
                               content_type='application/json')
        self.assertEqual(res.status_code, 400)
        data = res.get_json()
        self.assertEqual(data["status"], "error")
        self.assertIn("errors", data)

    def test_tc_api_005_post_student_duplicate_conflict(self):
        """TC-API-005: POST /api/students with existing student_id returns 409 Conflict."""
        # STU-2024-001 is already seeded
        duplicate_payload = {
            "student_id": "STU-2024-001",
            "name": "Duplicate Student",
            "email": "unique.email@example.edu",
            "department": "Information Technology",
            "year": "1st Year",
            "phone": "+91-98765-43001"
        }
        res = self.client.post('/api/students',
                               data=json.dumps(duplicate_payload),
                               content_type='application/json')
        self.assertEqual(res.status_code, 409)
        data = res.get_json()
        self.assertEqual(data["status"], "error")
        self.assertIn("already exists", data["message"])

    def test_tc_api_006_get_student_by_id(self):
        """TC-API-006: GET /api/students/<student_id> returns student object."""
        res = self.client.get('/api/students/STU-2024-001')
        self.assertEqual(res.status_code, 200)
        data = res.get_json()
        self.assertEqual(data["student"]["student_id"], "STU-2024-001")
        self.assertEqual(data["student"]["name"], "Aarav Sharma")

    def test_tc_api_007_get_student_not_found(self):
        """TC-API-007: GET /api/students/<student_id> non-existent returns 404."""
        res = self.client.get('/api/students/NON_EXISTENT_ID')
        self.assertEqual(res.status_code, 404)

    def test_tc_api_008_update_student(self):
        """TC-API-008: PUT /api/students/<student_id> updates student record."""
        update_payload = {
            "student_id": "STU-2024-002",
            "name": "Priya Patel Updated",
            "email": "priya.updated@example.edu",
            "department": "Computer Science",
            "year": "3rd Year",
            "phone": "+91-98765-99999",
            "status": "Active"
        }
        res = self.client.put('/api/students/STU-2024-002',
                              data=json.dumps(update_payload),
                              content_type='application/json')
        self.assertEqual(res.status_code, 200)

        # Verify update
        get_res = self.client.get('/api/students/STU-2024-002')
        self.assertEqual(get_res.get_json()["student"]["name"], "Priya Patel Updated")

    def test_tc_api_009_delete_student(self):
        """TC-API-009: DELETE /api/students/<student_id> removes student."""
        res = self.client.delete('/api/students/STU-2024-003')
        self.assertEqual(res.status_code, 200)

        # Confirm 404 on subsequent get
        get_res = self.client.get('/api/students/STU-2024-003')
        self.assertEqual(get_res.status_code, 404)

    def test_tc_api_010_dashboard_statistics(self):
        """TC-API-010: GET /api/stats returns aggregated metrics."""
        res = self.client.get('/api/stats')
        self.assertEqual(res.status_code, 200)
        data = res.get_json()["data"]
        self.assertIn("total_students", data)
        self.assertIn("department_distribution", data)
        self.assertIn("year_distribution", data)

    def test_tc_api_011_debug_set_scenario_and_status(self):
        """TC-API-011: Switch debugging scenario and verify via status endpoint."""
        res = self.client.post('/api/debug/set-scenario',
                               data=json.dumps({"scenario_id": "DB_NO_COMMIT"}),
                               content_type='application/json')
        self.assertEqual(res.status_code, 200)

        status_res = self.client.get('/api/debug/status')
        status_data = status_res.get_json()
        self.assertEqual(status_data["current_scenario"]["id"], "DB_NO_COMMIT")

        # Reset back to FIXED
        reset_res = self.client.post('/api/debug/reset-scenario')
        self.assertEqual(reset_res.status_code, 200)

if __name__ == '__main__':
    unittest.main()
