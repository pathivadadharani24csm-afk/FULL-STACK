# Student Management System – Database and Application-Level Debugging

An enterprise-grade, fully functional web application designed to systematically identify, reproduce, diagnose, and resolve the classic full-stack challenge:

> **Core Problem Statement:**
> *"A deployed Student Management System successfully adds student records but fails to display updated records. Examine possible database and application-level issues and provide a systematic testing and debugging procedure to identify and resolve the problem."*

---

## 1. Technology Stack

- **Frontend:** HTML5, CSS3, JavaScript (ES6+), Bootstrap 5, Bootstrap Icons, Chart.js
- **Backend:** Python 3.12, Flask RESTful API
- **Database:** SQLite 3 (with transaction commit/rollback controls, multi-database routing, and replica simulation)
- **Quality Assurance:** Python `unittest`, automated test runner, live interactive browser test matrix

---

## 2. System Architecture

```
┌────────────────────────────────────────────────────────────────────────┐
│                        FRONTEND CLIENT (BROWSER)                       │
│  ┌────────────────────┐ ┌────────────────────┐ ┌─────────────────────┐ │
│  │ Modern Dashboard   │ │ Student Directory  │ │ 10-Step Debugger    │ │
│  │ (Stats & Charts)   │ │ (Search/Edit/CSV)  │ │ & Test Matrix UI    │ │
│  └─────────┬──────────┘ └──────────┬─────────┘ └──────────┬──────────┘ │
└────────────┼───────────────────────┼──────────────────────┼────────────┘
             │                       │                      │
             ▼                       ▼                      ▼
┌────────────────────────────────────────────────────────────────────────┐
│                        FLASK REST API CONTROLLERS                      │
│   GET /api/students          POST /api/students      PUT /api/students │
│   GET /api/stats             GET  /api/health        DELETE /api/stu   │
│   GET /api/debug/status      POST /api/debug/set     GET /api/tests/run│
└────────────┬──────────────────────────────────────────────┬────────────┘
             │                                              │
             ▼                                              ▼
┌───────────────────────────┐                ┌───────────────────────────┐
│  DEBUG SIMULATION ENGINE  │                │    SQLITE STORAGE LAYER   │
│  • Transaction Committer  │                │  • students.db (Primary)  │
│  • Connection Switcher    │───────────────►│  • students_stale.db      │
│  • Query Filter Inspector │                │  • students_replica.db    │
│  • Stale Cache Engine     │                │  • ACID Transaction Logs  │
└───────────────────────────┘                └───────────────────────────┘
```

---

## 3. Directory Structure

```
student-management-system/
├── app.py                     # Flask REST API application & route handlers
├── config.py                  # Environment and database configuration
├── database.py                # Database schema, connections, and seed data
├── debug_controller.py        # Bug simulation engine & 10-step diagnostic logic
├── test_runner.py             # Test suite execution engine with detailed metrics
├── run_tests.py               # CLI test runner for terminal execution
├── requirements.txt           # Project dependencies
├── README.md                  # Comprehensive documentation and troubleshooting guide
├── data/                      # SQLite database files
│   ├── students.db            # Primary active database
│   ├── students_stale.db      # Stale database for bug simulation
│   └── students_replica.db    # Replica database for split read/write simulation
├── static/
│   ├── css/
│   │   └── style.css          # Blue & White modern responsive styles
│   └── js/
│       ├── app.js             # Core UI state, forms, tables, and Chart.js
│       ├── debug.js           # Interactive debugging lab & 10-step debugger
│       └── tests.js           # Live test runner UI and test matrix
├── templates/
│   └── index.html             # Single-page dashboard application
└── tests/
    ├── __init__.py
    ├── test_unit.py           # Unit tests (models, input validation)
    ├── test_database.py       # Database tests (ACID commits, constraints, CRUD)
    ├── test_api.py            # REST API integration tests
    ├── test_integration.py    # Discrepancy & fault injection integration tests
    ├── test_frontend_contracts.py # Frontend schema & query param contracts
    └── test_e2e.py            # End-to-end user journey tests
```

---

## 4. Key Features

### 4.1 Modern Blue & White Dashboard
- **Metric Cards:** Total Enrolled Students, Academic Departments, Year Distribution, and Live System Health.
- **Data Visualizations:** Interactive Chart.js charts displaying students by department (Bar Chart) and academic cohort distribution (Doughnut Chart).
- **Recent Registrations:** Real-time table showcasing the latest enrolled students.

### 4.2 Complete Student Directory
- **Search & Filtering:** Instant live text search (Name, Student ID, Email, Department) and dropdown filters by Department and Academic Year.
- **Actions:** Edit student modal, permanent delete confirmation modal, and CSV export.
- **Responsive Data Table:** Badges for department, year, status, and avatar initials.

### 4.3 Student Registration
- Required fields: Student ID (`STU-YYYY-NNN`), Full Name, Email, Department, Academic Year, Phone Number, and Status.
- **Convenience Tools:** *Auto-Fill Sample Record* button and *Generate Next ID* button for rapid testing.

---

## 5. Debugging Scenarios Demonstrated

The application features an interactive **Debugging Lab** where you can trigger any of the 10 failure scenarios with 1 click, observe the discrepancy, and apply the verified fix:

### Database-Level Issues:
1. **DB-1: Database Transaction Not Committed**
   - *Cause:* SQL INSERT executed on cursor, but `conn.commit()` is omitted. When connection closes, SQLite rolls back the transaction.
   - *Symptom:* Form says "Added Successfully", but record is missing on disk and absent in table.
2. **DB-2: Incorrect Database Connection**
   - *Cause:* Connection string opens legacy `students_stale.db` instead of `students.db`.
   - *Symptom:* Table displays an old frozen list; updates never reach production.
3. **DB-3: Split Database (Insert to Primary, Read from Replica)**
   - *Cause:* Write connection pool points to primary database, but Read route queries an un-synced replica.
   - *Symptom:* Direct query on `students.db` shows the record exists, yet `GET /api/students` omits it!
4. **DB-4: Incorrect SQL SELECT Query**
   - *Cause:* Query includes flawed predicate (e.g. `WHERE status = 'Archived'`).
   - *Symptom:* Record is safely saved in the database, but query filters out all new active students.
5. **DB-5: Database Caching or Stale Data**
   - *Cause:* Backend caches GET response in memory or browser caches 304 without invalidation on write.
   - *Symptom:* Database has fresh records, but API returns outdated cached JSON snapshot.

### Application-Level Issues:
6. **APP-1: API Response Not Updated**
   - *Cause:* Backend controller serializes a static module-level list instead of live DB query.
7. **APP-2: Fetch Request Not Executed / State Not Refreshed**
   - *Cause:* Form submit event handler omits calling `loadStudents()` after POST promise resolves.
   - *Symptom:* Record is in DB and API is updated, but table doesn't re-render until hard reload.
8. **APP-3: Incorrect API Endpoint**
   - *Cause:* Frontend fetches `/api/v1/get_all_students` which returns 404 Not Found.
9. **APP-4: Incorrect Frontend JavaScript / Key Mismatch**
   - *Cause:* Backend returns `{ "student_records": [...] }`, but frontend expects `data.students`.
   - *Symptom:* `TypeError: Cannot read properties of undefined` in browser console; table empty.
10. **APP-5: Backend Errors Not Handled Properly**
    - *Cause:* Unhandled 500 error returns HTML error page instead of JSON, crashing client parser.

---

## 6. The 10-Step Systematic Debugging Procedure

The app includes an interactive 10-step checklist built into the UI:

| Step # | Diagnostic Stage | Action & Tool |
|---|---|---|
| **Step 1** | **Reproduce the Issue** | Submit test student (e.g. `STU-2024-999`) and observe if table updates. |
| **Step 2** | **Check Database Insertion** | Direct SQLite shell query: `sqlite3 data/students.db "SELECT * FROM students WHERE student_id='STU-2024-999';"` |
| **Step 3** | **Verify DB Connections** | Inspect active connection path (`Config.PRIMARY_DB_PATH`) vs runtime file. |
| **Step 4** | **Check INSERT & SELECT Queries** | Inspect SQL query logs for incorrect `WHERE` clauses or schema mismatches. |
| **Step 5** | **Inspect Flask Backend Logs** | Check server terminal logs for exceptions, rollbacks, and HTTP status codes. |
| **Step 6** | **Test API Endpoints with cURL/Postman** | Bypass UI: `curl -X GET http://127.0.0.1:5000/api/students` |
| **Step 7** | **Inspect Frontend JS Console** | Open F12 DevTools Console for `TypeError`, `404`, or unhandled promises. |
| **Step 8** | **Verify API Responses & Payloads** | Inspect Network tab Response payload to verify expected keys (`data.students`). |
| **Step 9** | **Fix Identified Issue** | Apply targeted database or code fix; verify code diff in Debug Lab. |
| **Step 10** | **Retest Complete Application** | Run the 34-test regression suite to verify 100% pass rate. |

---

## 7. Automated Testing Suite

The project includes **34 automated test cases** across 6 testing tiers:

1. **Unit Testing (`test_unit.py`):** Input validation, ID regex, email sanitization.
2. **Database Testing (`test_database.py`):** SQLite ACID transaction commits, rollbacks, constraints.
3. **API Testing (`test_api.py`):** Status codes (200, 201, 400, 404, 409), payload validation.
4. **Integration Testing (`test_integration.py`):** Discrepancy simulations and recovery.
5. **Frontend Contract Testing (`test_frontend_contracts.py`):** Schema verification and query filters.
6. **End-to-End Testing (`test_e2e.py`):** Complete user workflow and problem reproduction/fix lifecycle.

---

## 8. Installation & Quick Start

### 8.1 Prerequisites
- Python 3.10+ (tested on Python 3.12)
- Modern web browser (Chrome, Firefox, Safari, Edge)

### 8.2 Setup Virtual Environment
```bash
cd /home/pathivada-dharani/.gemini/antigravity/scratch/student-management-system
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

### 8.3 Run Automated Tests
```bash
# Run CLI test matrix with detailed output
./run_tests.py

# Or run via pytest
pytest tests/
```

### 8.4 Start the Web Application
```bash
python3 app.py
```
Open your browser and navigate to:
```
http://127.0.0.1:5000
```

---

## 9. Demonstration Workflow

1. **Open Dashboard:** Observe 8 initial students and active department metrics.
2. **Add Student:** Click *Register Student*, click *Auto-Fill Sample Record*, and submit.
3. **Confirm DB & UI:** The student is persisted in `data/students.db` and immediately appears in the *Student Directory*.
4. **Simulate Problem:** Navigate to *Debugging Lab*, select `DB-1: Database transaction not committed`, and click *1-Click Reproduce Bug*.
5. **Diagnose Discrepancy:** The *Multi-Layer Verification Matrix* alerts that SQLite Disk Count is 8 while submission reported success!
6. **Follow 10-Step Debugger:** Step through the interactive checklist, inspect backend logs, and compare the code diff.
7. **Apply Fix & Retest:** Click *Restore Healthy Mode*, re-run the *Test Suite Runner*, and observe all 34 tests passing!
