"""
Configuration module for Student Management System.
Defines database paths, server settings, and debugging flags.
"""
import os

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
DATA_DIR = os.path.join(BASE_DIR, 'data')

# Ensure data directory exists
os.makedirs(DATA_DIR, exist_ok=True)

class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY', 'sms-dev-secret-key-debug-2024')
    
    # Primary working database
    PRIMARY_DB_PATH = os.path.join(DATA_DIR, 'students.db')
    
    # Stale database for bug simulation (points to out-of-sync or frozen DB)
    STALE_DB_PATH = os.path.join(DATA_DIR, 'students_stale.db')
    
    # Replica database for split read/write bug simulation
    REPLICA_DB_PATH = os.path.join(DATA_DIR, 'students_replica.db')
    
    # Server configuration
    HOST = '127.0.0.1'
    PORT = 5000
    DEBUG = True
