"""
Automated Test Runner Engine.
Executes Unit, Database, API, Integration, Frontend, and E2E test suites,
capturing granular pass/fail metrics, execution timings, and formatted test cases.
"""
import io
import time
import unittest
from datetime import datetime

# Import test suites
from tests.test_unit import TestStudentUnit
from tests.test_database import TestDatabase
from tests.test_api import TestAPI
from tests.test_integration import TestIntegration
from tests.test_frontend_contracts import TestFrontendContracts
from tests.test_e2e import TestE2EWorkflow

# Catalog of metadata for test cases
TEST_CASE_METADATA = {
    # Unit Tests
    "test_tc_unit_001_valid_student_data": {
        "id": "TC-UNIT-001",
        "category": "Unit Testing",
        "scenario": "Validate complete and properly formatted student dictionary.",
        "expected": "Validation function returns (True, []) with no error messages."
    },
    "test_tc_unit_002_missing_required_fields": {
        "id": "TC-UNIT-002",
        "category": "Unit Testing",
        "scenario": "Validate student data with blank/missing mandatory fields.",
        "expected": "Validation returns False and lists missing fields."
    },
    "test_tc_unit_003_invalid_student_id_format": {
        "id": "TC-UNIT-003",
        "category": "Unit Testing",
        "scenario": "Validate student ID with incorrect format (not STU-YYYY-NNN).",
        "expected": "Validation rejects ID and flags regex format mismatch."
    },
    "test_tc_unit_004_invalid_email_format": {
        "id": "TC-UNIT-004",
        "category": "Unit Testing",
        "scenario": "Validate student email without @ or domain.",
        "expected": "Validation rejects email format."
    },
    "test_tc_unit_005_invalid_department": {
        "id": "TC-UNIT-005",
        "category": "Unit Testing",
        "scenario": "Validate student assigned to unrecognized department.",
        "expected": "Validation flags department as invalid."
    },

    # Database Tests
    "test_tc_db_001_insert_and_commit_persistence": {
        "id": "TC-DB-001",
        "category": "Database Testing",
        "scenario": "Insert student record with conn.commit() to SQLite disk file.",
        "expected": "Row is saved and retrievable in a fresh database connection."
    },
    "test_tc_db_002_uncommitted_transaction_rollback": {
        "id": "TC-DB-002",
        "category": "Database Testing",
        "scenario": "Insert student record with auto_commit=False (uncommitted).",
        "expected": "Connection closes without commit; record is rolled back and not on disk."
    },
    "test_tc_db_003_unique_student_id_constraint": {
        "id": "TC-DB-003",
        "category": "Database Testing",
        "scenario": "Insert duplicate student_id into database.",
        "expected": "sqlite3.IntegrityError raised on unique constraint violation."
    },
    "test_tc_db_004_unique_email_constraint": {
        "id": "TC-DB-004",
        "category": "Database Testing",
        "scenario": "Insert duplicate student email into database.",
        "expected": "sqlite3.IntegrityError raised on email uniqueness constraint."
    },
    "test_tc_db_005_update_record": {
        "id": "TC-DB-005",
        "category": "Database Testing",
        "scenario": "Update student name and department in SQLite database.",
        "expected": "Database returns rowcount > 0 and updated values persist."
    },
    "test_tc_db_006_delete_record": {
        "id": "TC-DB-006",
        "category": "Database Testing",
        "scenario": "Delete student by student_id.",
        "expected": "Row is removed from database; subsequent lookup returns None."
    },
    "test_tc_db_007_statistics_calculation": {
        "id": "TC-DB-007",
        "category": "Database Testing",
        "scenario": "Aggregate student counts by department and academic year.",
        "expected": "Aggregations match exact counts of active students."
    },

    # API Tests
    "test_tc_api_001_health_check": {
        "id": "TC-API-001",
        "category": "API Testing",
        "scenario": "GET /api/health endpoint availability.",
        "expected": "HTTP 200 OK with status='healthy' and database_connected=True."
    },
    "test_tc_api_002_get_students_list": {
        "id": "TC-API-002",
        "category": "API Testing",
        "scenario": "GET /api/students returns full list of active students.",
        "expected": "HTTP 200 OK with status='success' and list of >= 8 students."
    },
    "test_tc_api_003_post_student_success": {
        "id": "TC-API-003",
        "category": "API Testing",
        "scenario": "POST /api/students with valid student payload.",
        "expected": "HTTP 201 Created with saved student details in response body."
    },
    "test_tc_api_004_post_student_validation_error": {
        "id": "TC-API-004",
        "category": "API Testing",
        "scenario": "POST /api/students with missing or invalid fields.",
        "expected": "HTTP 400 Bad Request with list of field error messages."
    },
    "test_tc_api_005_post_student_duplicate_conflict": {
        "id": "TC-API-005",
        "category": "API Testing",
        "scenario": "POST /api/students with existing student ID.",
        "expected": "HTTP 409 Conflict with clear uniqueness error message."
    },
    "test_tc_api_006_get_student_by_id": {
        "id": "TC-API-006",
        "category": "API Testing",
        "scenario": "GET /api/students/<student_id> for existing student.",
        "expected": "HTTP 200 OK returning matching student record."
    },
    "test_tc_api_007_get_student_not_found": {
        "id": "TC-API-007",
        "category": "API Testing",
        "scenario": "GET /api/students/<student_id> for non-existent ID.",
        "expected": "HTTP 404 Not Found."
    },
    "test_tc_api_008_update_student": {
        "id": "TC-API-008",
        "category": "API Testing",
        "scenario": "PUT /api/students/<student_id> with updated information.",
        "expected": "HTTP 200 OK and updated record in database."
    },
    "test_tc_api_009_delete_student": {
        "id": "TC-API-009",
        "category": "API Testing",
        "scenario": "DELETE /api/students/<student_id>.",
        "expected": "HTTP 200 OK and record removed from database."
    },
    "test_tc_api_010_dashboard_statistics": {
        "id": "TC-API-010",
        "category": "API Testing",
        "scenario": "GET /api/stats endpoint.",
        "expected": "HTTP 200 OK with total_students, departments, and years breakdown."
    },
    "test_tc_api_011_debug_set_scenario_and_status": {
        "id": "TC-API-011",
        "category": "API Testing",
        "scenario": "POST /api/debug/set-scenario and GET /api/debug/status.",
        "expected": "HTTP 200 OK and active scenario reflects changes."
    },

    # Integration Tests
    "test_tc_int_001_db_no_commit_discrepancy": {
        "id": "TC-INT-001",
        "category": "Integration Testing",
        "scenario": "Simulate DB_NO_COMMIT: row in cursor session but rolled back upon close.",
        "expected": "POST 201 occurs, but row count on disk does NOT change and GET API omits row."
    },
    "test_tc_int_002_split_database_discrepancy": {
        "id": "TC-INT-002",
        "category": "Integration Testing",
        "scenario": "Simulate DB_SPLIT_CONNECTION: write to primary, read from replica.",
        "expected": "Row exists in primary DB but GET /api/students omits row because it reads replica."
    },
    "test_tc_int_003_faulty_select_discrepancy": {
        "id": "TC-INT-003",
        "category": "Integration Testing",
        "scenario": "Simulate DB_FAULTY_SELECT: erroneous WHERE clause in read route.",
        "expected": "Row is in primary DB, but GET /api/students returns empty list due to filter."
    },
    "test_tc_int_004_fix_and_restore_healthy_state": {
        "id": "TC-INT-004",
        "category": "Integration Testing",
        "scenario": "Transition system from faulty state to FIXED mode and verify full pipeline.",
        "expected": "Healthy pipeline restored: added student immediately retrievable via GET API."
    },

    # Frontend Contract Tests
    "test_tc_fe_001_json_content_type_headers": {
        "id": "TC-FE-001",
        "category": "Frontend Testing",
        "scenario": "Verify API responses contain application/json Content-Type header.",
        "expected": "All API endpoints set Content-Type: application/json."
    },
    "test_tc_fe_002_student_payload_contract_keys": {
        "id": "TC-FE-002",
        "category": "Frontend Testing",
        "scenario": "Verify student JSON objects contain all keys required by UI table renderer.",
        "expected": "Each student record includes id, student_id, name, email, department, year, phone."
    },
    "test_tc_fe_003_search_query_filtering": {
        "id": "TC-FE-003",
        "category": "Frontend Testing",
        "scenario": "Verify frontend live search query filtering via ?search=.",
        "expected": "Returns only records matching query string."
    },
    "test_tc_fe_004_department_filtering": {
        "id": "TC-FE-004",
        "category": "Frontend Testing",
        "scenario": "Verify frontend department dropdown filter via ?department=.",
        "expected": "Returns only students enrolled in requested department."
    },
    "test_tc_fe_005_year_filtering": {
        "id": "TC-FE-005",
        "category": "Frontend Testing",
        "scenario": "Verify frontend academic year dropdown filter via ?year=.",
        "expected": "Returns only students in specified academic year."
    },

    # End-to-End Tests
    "test_tc_e2e_001_complete_successful_workflow": {
        "id": "TC-E2E-001",
        "category": "End-to-End Testing",
        "scenario": "Full User Workflow: Add student -> Verify in DB -> Verify in Student List -> Verify in Stats.",
        "expected": "Seamless end-to-end flow; student displayed instantly across all views."
    },
    "test_tc_e2e_002_failure_simulation_and_fix_workflow": {
        "id": "TC-E2E-002",
        "category": "End-to-End Testing",
        "scenario": "Problem Workflow: Inject bug -> Confirm record not displayed -> Diagnose root cause -> Apply fix -> Retest successfully.",
        "expected": "Failure reproduced deterministically, diagnosed, resolved, and verified by passing regression."
    }
}

class DetailedTestResult(unittest.TestResult):
    def __init__(self):
        super().__init__()
        self.test_cases = []
        self._test_start_time = None

    def startTest(self, test):
        super().startTest(test)
        self._test_start_time = time.perf_counter()

    def addSuccess(self, test):
        super().addSuccess(test)
        duration = round((time.perf_counter() - self._test_start_time) * 1000, 2)
        test_method = test._testMethodName
        meta = TEST_CASE_METADATA.get(test_method, {
            "id": test_method,
            "category": "General",
            "scenario": test.shortDescription() or test_method,
            "expected": "Test passes without exceptions."
        })
        self.test_cases.append({
            "test_id": meta["id"],
            "method": test_method,
            "category": meta["category"],
            "scenario": meta["scenario"],
            "expected_result": meta["expected"],
            "actual_result": "Executed successfully. Expected conditions met.",
            "status": "PASS",
            "duration_ms": duration,
            "error": None
        })

    def addFailure(self, test, err):
        super().addFailure(test, err)
        duration = round((time.perf_counter() - self._test_start_time) * 1000, 2)
        test_method = test._testMethodName
        meta = TEST_CASE_METADATA.get(test_method, {
            "id": test_method,
            "category": "General",
            "scenario": test.shortDescription() or test_method,
            "expected": "Assertion holds true."
        })
        err_msg = self._exc_info_to_string(err, test)
        self.test_cases.append({
            "test_id": meta["id"],
            "method": test_method,
            "category": meta["category"],
            "scenario": meta["scenario"],
            "expected_result": meta["expected"],
            "actual_result": f"Assertion failed: {err_msg.splitlines()[-1] if err_msg else 'Failed'}",
            "status": "FAIL",
            "duration_ms": duration,
            "error": err_msg
        })

    def addError(self, test, err):
        super().addError(test, err)
        duration = round((time.perf_counter() - self._test_start_time) * 1000, 2)
        test_method = test._testMethodName
        meta = TEST_CASE_METADATA.get(test_method, {
            "id": test_method,
            "category": "General",
            "scenario": test.shortDescription() or test_method,
            "expected": "No unhandled exceptions."
        })
        err_msg = self._exc_info_to_string(err, test)
        self.test_cases.append({
            "test_id": meta["id"],
            "method": test_method,
            "category": meta["category"],
            "scenario": meta["scenario"],
            "expected_result": meta["expected"],
            "actual_result": f"Unexpected error: {err_msg.splitlines()[-1] if err_msg else 'Error'}",
            "status": "ERROR",
            "duration_ms": duration,
            "error": err_msg
        })

def run_all_tests():
    """
    Executes all test suites and returns formatted report summary.
    """
    suite = unittest.TestSuite()
    
    # Load all suites in order
    loader = unittest.TestLoader()
    suite.addTests(loader.loadTestsFromTestCase(TestStudentUnit))
    suite.addTests(loader.loadTestsFromTestCase(TestDatabase))
    suite.addTests(loader.loadTestsFromTestCase(TestAPI))
    suite.addTests(loader.loadTestsFromTestCase(TestIntegration))
    suite.addTests(loader.loadTestsFromTestCase(TestFrontendContracts))
    suite.addTests(loader.loadTestsFromTestCase(TestE2EWorkflow))

    result = DetailedTestResult()
    start_time = time.perf_counter()
    suite.run(result)
    total_time_ms = round((time.perf_counter() - start_time) * 1000, 2)

    # Sort test cases by ID
    result.test_cases.sort(key=lambda x: x["test_id"])

    # Aggregate by category
    categories = {}
    for tc in result.test_cases:
        cat = tc["category"]
        if cat not in categories:
            categories[cat] = {"total": 0, "pass": 0, "fail": 0}
        categories[cat]["total"] += 1
        if tc["status"] == "PASS":
            categories[cat]["pass"] += 1
        else:
            categories[cat]["fail"] += 1

    total_tests = len(result.test_cases)
    total_passed = sum(1 for tc in result.test_cases if tc["status"] == "PASS")
    total_failed = total_tests - total_passed
    pass_rate = round((total_passed / total_tests * 100), 1) if total_tests > 0 else 0

    return {
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "total_tests": total_tests,
        "total_passed": total_passed,
        "total_failed": total_failed,
        "pass_rate_percent": pass_rate,
        "total_duration_ms": total_time_ms,
        "categories": categories,
        "test_cases": result.test_cases
    }
