"""
Debug Controller & Bug Simulation Engine.
Manages interactive bug scenarios, logging of requests/queries,
and systematic 10-step diagnostic guidance for both Database-Level
and Application-Level issues.
"""
import time
from datetime import datetime
from config import Config

class DebugController:
    # Scenario definitions
    SCENARIOS = {
        "FIXED": {
            "id": "FIXED",
            "name": "Healthy / Fixed System (Normal Operation)",
            "category": "Normal",
            "description": "All database and application layers operate correctly. Student records are inserted, committed, queried accurately, and frontend state refreshes immediately.",
            "symptom": "None. Adding a student immediately reflects in the database and frontend table.",
            "root_cause": "N/A - Clean implementation adhering to ACID and REST standards.",
            "db_insert_action": "commit_primary",
            "db_select_action": "select_primary",
            "frontend_behavior": "normal",
            "diagnostic_focus": "System operates as baseline reference.",
            "buggy_code": "# Correct implementation\nconn = get_db_connection()\ncursor.execute('INSERT INTO students ...')\nconn.commit()\nconn.close()",
            "fixed_code": "# Healthy baseline\nconn = get_db_connection()\ncursor.execute('INSERT INTO students ...')\nconn.commit()\nconn.close()"
        },
        # ---------------- DATABASE LEVEL ISSUES ----------------
        "DB_NO_COMMIT": {
            "id": "DB_NO_COMMIT",
            "name": "DB-1: Database Transaction Not Committed",
            "category": "Database-Level",
            "description": "The backend executes the SQL INSERT statement on the cursor, but fails to call conn.commit(). When the database connection closes, SQLite rolls back the uncommitted transaction.",
            "symptom": "User sees 'Student added successfully' notification, but the student table does not show the new record. Direct SQLite query reveals 0 records were persisted to disk.",
            "root_cause": "Missing conn.commit() in the database insertion routine. The row was inserted into the in-memory cursor session but discarded upon connection termination.",
            "db_insert_action": "no_commit",
            "db_select_action": "select_primary",
            "frontend_behavior": "normal",
            "diagnostic_focus": "Verify database transaction lifecycle; inspect cursor.rowcount vs disk persistence.",
            "buggy_code": "def insert_student(data):\n    conn = get_db_connection()\n    cursor = conn.cursor()\n    cursor.execute('INSERT INTO students ...', (...))\n    # BUG: conn.commit() is MISSING!\n    conn.close()  # Rolls back uncommitted transaction in SQLite",
            "fixed_code": "def insert_student(data):\n    conn = get_db_connection()\n    cursor = conn.cursor()\n    cursor.execute('INSERT INTO students ...', (...))\n    conn.commit()  # FIX: Explicitly commit the transaction\n    conn.close()"
        },
        "DB_WRONG_CONNECTION": {
            "id": "DB_WRONG_CONNECTION",
            "name": "DB-2: Incorrect Database Connection",
            "category": "Database-Level",
            "description": "The application connects to a legacy or stale database file (students_stale.db) instead of the active production database.",
            "symptom": "The student list displays an outdated, frozen list of students. Adding records modifies the stale database or disconnects from production reporting.",
            "root_cause": "The connection string or DB path variable points to an old database file (e.g., config typo or legacy path students_stale.db).",
            "db_insert_action": "commit_stale",
            "db_select_action": "select_stale",
            "frontend_behavior": "normal",
            "diagnostic_focus": "Verify Config.PRIMARY_DB_PATH and runtime connection file descriptor / path.",
            "buggy_code": "# BUG: Connection points to an outdated or temporary database path\nDB_PATH = 'data/students_stale.db'\nconn = sqlite3.connect(DB_PATH)",
            "fixed_code": "# FIX: Verify environment and use the configured primary database path\nDB_PATH = Config.PRIMARY_DB_PATH  # 'data/students.db'\nconn = sqlite3.connect(DB_PATH)"
        },
        "DB_SPLIT_CONNECTION": {
            "id": "DB_SPLIT_CONNECTION",
            "name": "DB-3: Split Database (Insert to Primary, Read from Replica)",
            "category": "Database-Level",
            "description": "Records are inserted into primary database (students.db), but the SELECT query fetches from an un-synced replica (students_replica.db).",
            "symptom": "Checking students.db directly confirms the record was saved! Yet GET /api/students returns an old snapshot because it reads from the replica.",
            "root_cause": "Asymmetric data access configuration: Write connection pool points to master/primary, while Read connection pool points to an un-replicated slave or detached database.",
            "db_insert_action": "commit_primary",
            "db_select_action": "select_replica",
            "frontend_behavior": "normal",
            "diagnostic_focus": "Compare database file paths and row counts between INSERT connection and SELECT connection.",
            "buggy_code": "# BUG: Write to primary, but Read from outdated replica\ndef add_student(data):\n    conn = get_connection('data/students.db')\n    ...\ndef get_students():\n    conn = get_connection('data/students_replica.db') # MISMATCH!\n    ...",
            "fixed_code": "# FIX: Harmonize data source or verify replication synchronization\ndef get_students():\n    conn = get_connection('data/students.db')  # MATCHES primary write target\n    ..."
        },
        "DB_FAULTY_SELECT": {
            "id": "DB_FAULTY_SELECT",
            "name": "DB-4: Incorrect SQL SELECT Query",
            "category": "Database-Level",
            "description": "The student is inserted with status='Active', but the SELECT query has an erroneous WHERE condition (e.g. status='Archived' or created_at < '2024-01-01').",
            "symptom": "Record exists in students.db, but the SELECT query filters it out. Frontend shows 0 or fewer students.",
            "root_cause": "Flawed SQL predicate logic: The query uses incorrect filtering criteria that excludes newly created student records.",
            "db_insert_action": "commit_primary",
            "db_select_action": "faulty_select",
            "frontend_behavior": "normal",
            "diagnostic_focus": "Inspect actual SQL query executed by Flask and check WHERE conditions against table schema defaults.",
            "buggy_code": "# BUG: Erroneous WHERE clause filters out all active records\nquery = \"SELECT * FROM students WHERE status = 'Archived' ORDER BY id DESC\"",
            "fixed_code": "# FIX: Remove flawed condition or use appropriate filter\nquery = \"SELECT * FROM students WHERE status = 'Active' ORDER BY id DESC\""
        },
        "DB_QUERY_CACHE": {
            "id": "DB_QUERY_CACHE",
            "name": "DB-5: Database Caching or Stale Data",
            "category": "Database-Level",
            "description": "The backend caches the results of the student list in memory or honors a 304 Not Modified cache without invalidating it when an INSERT occurs.",
            "symptom": "Record is saved in database, but the API continues serving a cached JSON response indefinitely.",
            "root_cause": "Cache Invalidation failure: The cache key is not purged or refreshed upon POST/PUT/DELETE operations.",
            "db_insert_action": "commit_primary_no_cache_invalidation",
            "db_select_action": "cached_select",
            "frontend_behavior": "normal",
            "diagnostic_focus": "Inspect HTTP Cache headers and backend query cache invalidation routines.",
            "buggy_code": "# BUG: Cached response is returned without checking for mutations\nif 'students_list' in cache:\n    return cache['students_list']\n# (POST route never cleared cache['students_list']!)",
            "fixed_code": "# FIX: Purge or invalidate cache on every mutating operation\n@app.route('/api/students', methods=['POST'])\ndef create_student():\n    # ... insert into db ...\n    cache.pop('students_list', None)  # FIX: Invalidate cache"
        },
        # ---------------- APPLICATION LEVEL ISSUES ----------------
        "APP_STALE_RESPONSE": {
            "id": "APP_STALE_RESPONSE",
            "name": "APP-1: API Response Not Updated",
            "category": "Application-Level",
            "description": "The backend route handles the request but serializes a static snapshot or stale in-memory array rather than querying fresh database rows.",
            "symptom": "Database contains all updated records, but API payload returns frozen static list.",
            "root_cause": "Route handler returns a global variable initialized at server startup instead of executing a fresh query.",
            "db_insert_action": "commit_primary",
            "db_select_action": "stale_api_response",
            "frontend_behavior": "normal",
            "diagnostic_focus": "Verify backend controller response serialization logic against database cursor.",
            "buggy_code": "# BUG: Returning frozen module-level list instead of live DB query\nSTATIC_STUDENTS = [...initial snapshot...]\n@app.route('/api/students')\ndef get_students():\n    return jsonify({'students': STATIC_STUDENTS})",
            "fixed_code": "# FIX: Query database fresh on every API invocation\n@app.route('/api/students')\ndef get_students():\n    students = database.get_all_students()\n    return jsonify({'students': students})"
        },
        "APP_FRONTEND_NO_REFRESH": {
            "id": "APP_FRONTEND_NO_REFRESH",
            "name": "APP-2: Fetch Request Not Executed / State Not Refreshed",
            "category": "Application-Level",
            "description": "After successfully saving a student, the frontend JavaScript event handler omits calling loadStudents() to refresh table state.",
            "symptom": "Student record is successfully saved in DB and API is updated. However, the UI student table does not re-render until the user manually hard-refreshes the whole browser page.",
            "root_cause": "Missing fetch invocation in the asynchronous Promise resolution chain of the submit button handler.",
            "db_insert_action": "commit_primary",
            "db_select_action": "select_primary",
            "frontend_behavior": "omit_fetch_after_insert",
            "diagnostic_focus": "Inspect browser network waterfall tab: check if GET /api/students is dispatched after POST 201.",
            "buggy_code": "// BUG: Form submission resolves without triggering re-fetch\nfetch('/api/students', { method: 'POST', body: ... })\n  .then(res => res.json())\n  .then(data => {\n      showToast('Student Added!');\n      // BUG: forgot to call loadStudents()!\n  });",
            "fixed_code": "// FIX: Trigger re-fetch and update UI state immediately\nfetch('/api/students', { method: 'POST', body: ... })\n  .then(res => res.json())\n  .then(data => {\n      showToast('Student Added!');\n      loadStudents();      // FIX: Refresh table\n      loadDashboardStats(); // FIX: Refresh counters\n  });"
        },
        "APP_WRONG_ENDPOINT": {
            "id": "APP_WRONG_ENDPOINT",
            "name": "APP-3: Incorrect API Endpoint",
            "category": "Application-Level",
            "description": "Frontend fetch request targets an invalid or outdated URL (/api/v1/get_all_students) resulting in a 404 Not Found error.",
            "symptom": "Table remains empty or stuck with a spinner; browser console shows: 'GET http://.../api/v1/get_all_students 404 (NOT FOUND)'.",
            "root_cause": "Frontend routing constant points to a non-existent endpoint or obsolete versioned path.",
            "db_insert_action": "commit_primary",
            "db_select_action": "select_primary",
            "frontend_behavior": "wrong_endpoint",
            "diagnostic_focus": "Check browser DevTools Network tab for 404 status codes and verify endpoint URL in JS.",
            "buggy_code": "// BUG: Typo or legacy endpoint in frontend request\nconst API_URL = '/api/v1/get_all_students'; // 404 Not Found\nfetch(API_URL)...",
            "fixed_code": "// FIX: Direct request to valid REST API route\nconst API_URL = '/api/students'; // 200 OK\nfetch(API_URL)..."
        },
        "APP_KEY_MISMATCH": {
            "id": "APP_KEY_MISMATCH",
            "name": "APP-4: Incorrect Frontend JavaScript / Key Mismatch",
            "category": "Application-Level",
            "description": "Backend returns JSON with key {'student_data': [...]}, but frontend script expects data.students. Mapping yields undefined and renders an empty table.",
            "symptom": "API response returns 200 OK with valid student records, but table says 'No students found'. Console shows TypeError: Cannot read properties of undefined.",
            "root_cause": "Schema mismatch between backend API response contract and frontend client parser.",
            "db_insert_action": "commit_primary",
            "db_select_action": "mismatched_key_response",
            "frontend_behavior": "normal",
            "diagnostic_focus": "Compare API response JSON payload structure with frontend JavaScript consumption properties.",
            "buggy_code": "// Backend returned: { \"status\": \"success\", \"student_records\": [...] }\n// Frontend BUG: \nconst list = data.students; // undefined!\nlist.forEach(s => renderRow(s)); // Throws TypeError: list is undefined",
            "fixed_code": "// FIX: Harmonize property key across contract\nconst list = data.students || data.student_records || [];\nlist.forEach(s => renderRow(s));"
        },
        "APP_UNHANDLED_500": {
            "id": "APP_UNHANDLED_500",
            "name": "APP-5: Backend Errors Not Handled Properly",
            "category": "Application-Level",
            "description": "An unhandled exception occurs in backend serialization or database query, returning an unformatted HTTP 500 HTML error page instead of JSON.",
            "symptom": "Frontend fetch throws SyntaxError: Unexpected token '<', '<!doctype '... is not valid JSON.",
            "root_cause": "Missing try-except blocks and lack of global Flask error handlers converting 500 exceptions to structured JSON responses.",
            "db_insert_action": "commit_primary",
            "db_select_action": "trigger_500_error",
            "frontend_behavior": "normal",
            "diagnostic_focus": "Inspect Flask backend logs for tracebacks and implement Flask @app.errorhandler(500).",
            "buggy_code": "# BUG: Unhandled exception crashes route\n@app.route('/api/students')\ndef get_students():\n    raise RuntimeError('Database lock timeout or unhandled exception!')\n    # Flask responds with default 500 HTML page!",
            "fixed_code": "# FIX: Wrap route in try-except and provide global JSON error handler\n@app.errorhandler(Exception)\ndef handle_error(err):\n    return jsonify({'error': str(err), 'status': 'failed'}), 500"
        }
    }

    # 10-Step Systematic Debugging Procedure Template
    TEN_STEP_PROCEDURE = [
        {
            "step": 1,
            "title": "Reproduce the Issue",
            "description": "Fill the Add Student form, submit the record, and observe if the table fails to display the newly inserted record.",
            "tool": "UI Form & Browser Inspection",
            "action": "Submit test student (e.g. STU-2024-999) and observe table state."
        },
        {
            "step": 2,
            "title": "Check Whether Records are Inserted into Database",
            "description": "Query the SQLite database directly from shell/CLI to determine if the record exists on disk or if insertion failed.",
            "tool": "Direct SQLite Query CLI",
            "action": "sqlite3 data/students.db \"SELECT * FROM students WHERE student_id='STU-2024-999';\""
        },
        {
            "step": 3,
            "title": "Verify Database Connections",
            "description": "Check which database file is being opened by Flask during INSERT and SELECT operations.",
            "tool": "Connection Inspector",
            "action": "Inspect Config.PRIMARY_DB_PATH and runtime file path."
        },
        {
            "step": 4,
            "title": "Check INSERT and SELECT Queries",
            "description": "Review the exact SQL queries executed by the application, including WHERE clauses, column names, and parameters.",
            "tool": "SQL Query Logger",
            "action": "Inspect executed SQL: SELECT query vs table column defaults."
        },
        {
            "step": 5,
            "title": "Inspect Flask Backend Logs",
            "description": "Examine the backend terminal stdout/stderr for HTTP status codes, exceptions, transaction rollbacks, or tracebacks.",
            "tool": "Backend Console / Log Viewer",
            "action": "Review Flask server output logs for errors or warnings."
        },
        {
            "step": 6,
            "title": "Test API Endpoints Using Postman or cURL",
            "description": "Bypass the frontend UI completely to test GET /api/students and POST /api/students directly.",
            "tool": "Postman / cURL",
            "action": "curl -X GET http://127.0.0.1:5000/api/students"
        },
        {
            "step": 7,
            "title": "Inspect Frontend JavaScript Console Errors",
            "description": "Open Chrome/Firefox Developer Tools (F12 -> Console) to check for JavaScript exceptions, uncaught promises, or network failures.",
            "tool": "Browser DevTools (F12 Console)",
            "action": "Check Console tab for TypeError, SyntaxError, or 404/500 errors."
        },
        {
            "step": 8,
            "title": "Verify API Responses & Payloads",
            "description": "Examine the Network tab Response tab to check whether the JSON payload contains the expected keys and records.",
            "tool": "Browser DevTools (Network Tab)",
            "action": "Inspect HTTP Response Body: Check if student is present in students array."
        },
        {
            "step": 9,
            "title": "Fix the Identified Issue",
            "description": "Apply the targeted fix at the database level (e.g. commit transaction, fix DB path, correct SQL) or application level (e.g. refresh state, fix key mismatch).",
            "tool": "Source Code Editor / Fix Toggle",
            "action": "Apply the fix and verify code diff."
        },
        {
            "step": 10,
            "title": "Retest the Complete Application",
            "description": "Perform end-to-end regression testing: register another student, verify DB persistence, verify API, and confirm instant UI rendering.",
            "tool": "Automated Test Suite & Live UI",
            "action": "Run full test suite (Unit, Integration, DB, API, E2E) to verify 100% pass."
        }
    ]

    def __init__(self):
        self.active_scenario = "FIXED"
        self.in_memory_cache = None  # Used for DB_QUERY_CACHE scenario
        self.logs = []
        self._log_limit = 200
        self.add_log("INFO", "DebugController initialized in FIXED (Healthy) mode.")

    def set_scenario(self, scenario_id):
        if scenario_id in self.SCENARIOS:
            old = self.active_scenario
            self.active_scenario = scenario_id
            # Reset cache if switching away or to cache scenario
            if scenario_id == "DB_QUERY_CACHE":
                # Prime the cache with existing data
                from database import get_all_students
                self.in_memory_cache = get_all_students(Config.PRIMARY_DB_PATH)
                self.add_log("WARN", f"Scenario set to DB_QUERY_CACHE. In-memory cache primed with {len(self.in_memory_cache)} records. Cache invalidation DISABLED.")
            else:
                self.in_memory_cache = None
            
            self.add_log("INFO", f"Debug Scenario switched: '{old}' -> '{scenario_id}' ({self.SCENARIOS[scenario_id]['name']})")
            return True, self.SCENARIOS[scenario_id]
        return False, None

    def reset_to_fixed(self):
        return self.set_scenario("FIXED")

    def get_current_scenario_info(self):
        info = dict(self.SCENARIOS[self.active_scenario])
        info["is_buggy"] = (self.active_scenario != "FIXED")
        return info

    def get_all_scenarios(self):
        return [
            {
                "id": k,
                "name": v["name"],
                "category": v["category"],
                "description": v["description"],
                "is_active": (k == self.active_scenario)
            }
            for k, v in self.SCENARIOS.items()
        ]

    def add_log(self, level, message, details=None):
        entry = {
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3],
            "level": level.upper(),
            "message": message,
            "details": details or {},
            "active_scenario": self.active_scenario
        }
        self.logs.append(entry)
        if len(self.logs) > self._log_limit:
            self.logs.pop(0)

    def get_logs(self, limit=50):
        return self.logs[-limit:]

    def clear_logs(self):
        self.logs = []
        self.add_log("INFO", "Backend logs cleared by user.")

# Global singleton instance
debug_controller = DebugController()
